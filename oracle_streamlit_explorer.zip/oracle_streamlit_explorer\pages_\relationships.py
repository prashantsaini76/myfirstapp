"""ER-style relationship explorer.

Layouts:
  - Graph view: Graphviz "record" nodes showing each table's PK + FK columns,
    edges labelled with child→parent column mapping. Rank direction adapts
    to depth so big graphs stay readable.
  - List view: parent / child relationship tables for the center table.
"""
from __future__ import annotations

import html

import graphviz
import pandas as pd
import streamlit as st

from components.cards import require_schema
from components.data_grid import interactive_grid
from db import metadata_queries as mq


# ----------------------------------------------------------------- helpers

def _pk_columns(env: str, owner: str, table: str) -> set[str]:
    cons = mq.table_constraints(env, owner, table)
    if cons.empty:
        return set()
    return set(
        cons.loc[cons["CONSTRAINT_TYPE"] == "P", "COLUMN_NAME"].dropna().tolist()
    )


def _fk_columns(env: str, owner: str, table: str) -> set[str]:
    fk = mq.foreign_keys_outgoing(env, owner, table)
    if fk.empty:
        return set()
    return set(fk["CHILD_COLUMN"].dropna().tolist())


def _record_label(owner: str, table: str, pk: set[str], fk: set[str],
                  *, focus: bool) -> str:
    """Build an HTML-like label for a Graphviz record node."""
    header_bg = "#C74634" if focus else "#1F2937"
    header_fg = "#FFFFFF"
    body_bg = "#FFF7F4" if focus else "#FFFFFF"
    border = "#C74634" if focus else "#94A3B8"

    rows = [
        f'<TR><TD BGCOLOR="{header_bg}" ALIGN="LEFT">'
        f'<FONT COLOR="{header_fg}"><B>  {html.escape(owner)}.{html.escape(table)}  </B></FONT>'
        f'</TD></TR>'
    ]
    cols = sorted(pk) + sorted(fk - pk)
    if not cols:
        rows.append(f'<TR><TD BGCOLOR="{body_bg}" ALIGN="LEFT">'
                    f'<FONT POINT-SIZE="9" COLOR="#6B7280">'
                    f'  (no key columns)  </FONT></TD></TR>')
    else:
        for c in cols[:8]:  # cap so big tables don't blow up the node
            tag = "PK" if c in pk else "FK"
            tag_color = "#C74634" if tag == "PK" else "#2563EB"
            rows.append(
                f'<TR><TD BGCOLOR="{body_bg}" ALIGN="LEFT">'
                f'<FONT POINT-SIZE="9" COLOR="{tag_color}"><B>{tag}</B></FONT> '
                f'<FONT POINT-SIZE="9">  {html.escape(c)}</FONT>'
                f'</TD></TR>'
            )
        if len(cols) > 8:
            rows.append(
                f'<TR><TD BGCOLOR="{body_bg}" ALIGN="LEFT">'
                f'<FONT POINT-SIZE="8" COLOR="#6B7280">  …{len(cols) - 8} more  </FONT>'
                f'</TD></TR>'
            )
    table_html = (
        f'<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" '
        f'BGCOLOR="{border}">{"".join(rows)}</TABLE>'
    )
    return f"<{table_html}>"


def _build_graph(env: str, owner: str, table: str, depth: int) -> graphviz.Digraph:
    rankdir = "LR" if depth <= 2 else "TB"
    g = graphviz.Digraph(
        "er",
        graph_attr={
            "rankdir": rankdir,
            "splines": "spline",
            "bgcolor": "transparent",
            "nodesep": "0.45",
            "ranksep": "0.7",
            "pad": "0.2",
        },
    )
    g.attr("node", shape="plaintext", fontname="Helvetica")
    g.attr("edge", color="#94A3B8", fontname="Helvetica",
           fontsize="9", fontcolor="#475569", arrowsize="0.8")

    seen: set[tuple[str, str]] = set()
    edges: set[tuple[str, str, str, str]] = set()

    def add_node(o: str, t: str, *, focus: bool = False) -> None:
        key = (o, t)
        if key in seen:
            return
        seen.add(key)
        pk = _pk_columns(env, o, t)
        fk = _fk_columns(env, o, t)
        g.node(f"{o}.{t}", label=_record_label(o, t, pk, fk, focus=focus))

    def add_edge(co: str, ct: str, cc: str, po: str, pt: str, pc: str) -> None:
        sig = (f"{co}.{ct}", f"{po}.{pt}", cc, pc)
        if sig in edges:
            return
        edges.add(sig)
        g.edge(
            f"{co}.{ct}", f"{po}.{pt}",
            label=f"  {cc} → {pc}  ",
            arrowhead="vee",
        )

    add_node(owner, table, focus=True)
    frontier = [(owner, table)]
    for _ in range(max(1, depth)):
        next_frontier: list[tuple[str, str]] = []
        for o, t in frontier:
            for _, r in mq.foreign_keys_outgoing(env, o, t).iterrows():
                po, pt = r["PARENT_OWNER"], r["PARENT_TABLE"]
                if po and pt:
                    add_node(po, pt)
                    add_edge(o, t, r["CHILD_COLUMN"], po, pt, r["PARENT_COLUMN"])
                    next_frontier.append((po, pt))
            for _, r in mq.foreign_keys_incoming(env, o, t).iterrows():
                co, ct = r["CHILD_OWNER"], r["CHILD_TABLE"]
                if co and ct:
                    add_node(co, ct)
                    add_edge(co, ct, r["CHILD_COLUMN"], o, t, r["PARENT_COLUMN"])
                    next_frontier.append((co, ct))
        frontier = next_frontier
        if not frontier:
            break
    return g


# ------------------------------------------------------------------- page

def render(env: str, owner: str | None) -> None:
    if not require_schema(owner):
        return

    st.title("Relationships")
    st.caption(f"{env} · {owner}")

    with st.spinner(f"Loading tables from {owner}…"):
        tables = mq.list_tables(env, owner)["TABLE_NAME"].tolist()
    if not tables:
        st.info("No tables in this schema.")
        return

    c1, c2 = st.columns([3, 1])
    table = c1.selectbox("Center table", tables, index=None,
                         placeholder="Choose a table…")
    depth = c2.slider("Depth", 1, 4, 1,
                      help="How many hops out from the center table to follow.")
    if not table:
        return

    # ----- summary KPI row -----
    with st.spinner("Loading foreign keys…"):
        fk_out = mq.foreign_keys_outgoing(env, owner, table)
        fk_in = mq.foreign_keys_incoming(env, owner, table)

    parents = fk_out["PARENT_TABLE"].nunique() if not fk_out.empty else 0
    children = fk_in["CHILD_TABLE"].nunique() if not fk_in.empty else 0
    k1, k2, k3 = st.columns(3)
    k1.metric("Parent tables (this → other)", parents)
    k2.metric("Child tables (other → this)", children)
    k3.metric("FK relationships", len(fk_out) + len(fk_in))

    # ----- views -----
    tabs = st.tabs(["Diagram", "Parents", "Children", "All edges"])

    with tabs[0]:
        if depth >= 3:
            st.caption(
                "Large depths can produce wide graphs. Switch to the "
                "Parents/Children/All edges tabs for a tabular view."
            )
        with st.spinner("Building relationship diagram…"):
            graph = _build_graph(env, owner, table, depth)
        st.graphviz_chart(graph, use_container_width=True)
        st.caption(
            "Arrows point child → parent. **PK** columns shown in red, "
            "**FK** columns in blue. The center table is highlighted."
        )

    with tabs[1]:
        if fk_out.empty:
            st.info("This table does not reference any other table.")
        else:
            interactive_grid(
                fk_out, key="rel_out",
                download_basename=f"{owner}_{table}_parents",
                height=380, show_search=True,
            )

    with tabs[2]:
        if fk_in.empty:
            st.info("No other table references this one.")
        else:
            interactive_grid(
                fk_in, key="rel_in",
                download_basename=f"{owner}_{table}_children",
                height=380, show_search=True,
            )

    with tabs[3]:
        combined = pd.concat(
            [
                fk_out.assign(
                    DIRECTION="out",
                    SOURCE=f"{owner}.{table}",
                    TARGET=lambda d: d["PARENT_OWNER"].fillna("") + "."
                                     + d["PARENT_TABLE"].fillna(""),
                )[["DIRECTION", "SOURCE", "TARGET", "CHILD_COLUMN",
                   "PARENT_COLUMN", "CONSTRAINT_NAME"]],
                fk_in.assign(
                    DIRECTION="in",
                    SOURCE=lambda d: d["CHILD_OWNER"].fillna("") + "."
                                     + d["CHILD_TABLE"].fillna(""),
                    TARGET=f"{owner}.{table}",
                )[["DIRECTION", "SOURCE", "TARGET", "CHILD_COLUMN",
                   "PARENT_COLUMN", "CONSTRAINT_NAME"]],
            ],
            ignore_index=True,
        )
        if combined.empty:
            st.info("No foreign-key edges connected to this table.")
        else:
            interactive_grid(
                combined, key="rel_all",
                download_basename=f"{owner}_{table}_edges",
                height=420, show_search=True,
            )
