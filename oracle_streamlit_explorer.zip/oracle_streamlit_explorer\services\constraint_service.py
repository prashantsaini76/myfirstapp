"""Constraint browsing helpers."""
from __future__ import annotations

import pandas as pd

from db import metadata_queries as mq
from utils.formatting import constraint_label


def constraints_for_schema(
    env: str,
    owner: str,
    *,
    table_filter: str | None = None,
    type_filter: list[str] | None = None,
    name_filter: str | None = None,
) -> pd.DataFrame:
    df = mq.all_constraints_in_schema(env, owner).copy()
    if df.empty:
        return df

    df["TYPE_LABEL"] = df["CONSTRAINT_TYPE"].map(constraint_label)

    if table_filter:
        df = df[df["TABLE_NAME"].str.contains(table_filter.upper(), na=False)]
    if name_filter:
        df = df[df["CONSTRAINT_NAME"].str.contains(name_filter.upper(), na=False)]
    if type_filter:
        df = df[df["CONSTRAINT_TYPE"].isin(type_filter)]
    return df.reset_index(drop=True)
