"""Build a safe, parameterised WHERE clause from structured UI filters.

Each filter is a dict:
    {"column": "STATUS", "op": "=", "value": "A"}
Operators supported:
    =, !=, >, <, >=, <=, LIKE, NOT LIKE, IN, NOT IN, BETWEEN,
    IS NULL, IS NOT NULL.

All literals are bound — never spliced into SQL. Column names are
validated through assert_identifier.
"""
from __future__ import annotations

from typing import Any, Iterable

from utils.sql_validator import UnsafeSQLError, assert_identifier

OPERATORS = [
    "=", "!=", ">", "<", ">=", "<=",
    "LIKE", "NOT LIKE",
    "IN", "NOT IN",
    "BETWEEN",
    "IS NULL", "IS NOT NULL",
]
NEEDS_NO_VALUE = {"IS NULL", "IS NOT NULL"}
NEEDS_LIST = {"IN", "NOT IN"}
NEEDS_TWO = {"BETWEEN"}


def _coerce_for_column(value: str, data_type: str | None) -> Any:
    """Best-effort coercion based on Oracle column type."""
    if value is None:
        return None
    dt = (data_type or "").upper()
    s = str(value).strip()
    if dt.startswith("NUMBER") or dt in {"FLOAT", "BINARY_FLOAT", "BINARY_DOUBLE", "INTEGER"}:
        if s == "":
            return None
        try:
            if "." in s:
                return float(s)
            return int(s)
        except ValueError:
            return s  # let the DB raise
    return s


def build_where(
    filters: Iterable[dict],
    column_types: dict[str, str] | None = None,
) -> tuple[str, dict[str, Any]]:
    """Return (where_sql_without_keyword, bind_dict). Empty filters -> ('', {})."""
    column_types = column_types or {}
    parts: list[str] = []
    binds: dict[str, Any] = {}

    for i, f in enumerate(filters):
        col = f.get("column")
        op = (f.get("op") or "=").upper()
        if not col or op not in OPERATORS:
            continue

        assert_identifier(col, kind="column")
        col_sql = f'"{col}"'
        dtype = column_types.get(col)

        if op in NEEDS_NO_VALUE:
            parts.append(f"{col_sql} {op}")
            continue

        if op in NEEDS_LIST:
            raw = f.get("value") or ""
            items = [v.strip() for v in str(raw).split(",") if v.strip() != ""]
            if not items:
                raise UnsafeSQLError(
                    f"Operator {op} on {col} requires at least one value."
                )
            placeholders = []
            for j, item in enumerate(items):
                key = f"v{i}_{j}"
                binds[key] = _coerce_for_column(item, dtype)
                placeholders.append(f":{key}")
            parts.append(f"{col_sql} {op} ({', '.join(placeholders)})")
            continue

        if op in NEEDS_TWO:
            v1, v2 = f.get("value"), f.get("value2")
            if v1 in (None, "") or v2 in (None, ""):
                raise UnsafeSQLError(f"BETWEEN on {col} requires two values.")
            k1, k2 = f"v{i}a", f"v{i}b"
            binds[k1] = _coerce_for_column(v1, dtype)
            binds[k2] = _coerce_for_column(v2, dtype)
            parts.append(f"{col_sql} BETWEEN :{k1} AND :{k2}")
            continue

        # single-value operators
        val = f.get("value")
        if val is None or val == "":
            raise UnsafeSQLError(f"Operator {op} on {col} requires a value.")
        key = f"v{i}"
        binds[key] = _coerce_for_column(val, dtype)
        parts.append(f"{col_sql} {op} :{key}")

    return " AND ".join(parts), binds
