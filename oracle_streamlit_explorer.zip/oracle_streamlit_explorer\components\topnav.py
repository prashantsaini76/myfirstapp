"""Horizontal top navigation bar (powered by streamlit-option-menu)."""
from __future__ import annotations

import streamlit as st
from streamlit_option_menu import option_menu

PAGES = [
    ("Dashboard",      "dashboard"),
    ("Table Explorer", "tables"),
    ("Column Search",  "column_search"),
    ("Code Lookups",   "lookups"),
    ("Constraints",    "constraints"),
    ("Relationships",  "relationships"),
    ("SQL Console",    "sql_console"),
    ("Export",         "export"),
]


def render() -> str:
    labels = [label for label, _ in PAGES]
    keys = [key for _, key in PAGES]

    if "active_page" not in st.session_state:
        st.session_state["active_page"] = keys[0]

    current_label = next(
        (l for l, k in PAGES if k == st.session_state["active_page"]),
        labels[0],
    )

    selected = option_menu(
        menu_title=None,
        options=labels,
        default_index=labels.index(current_label),
        orientation="horizontal",
        key="topnav_menu",
        styles={
            "container": {
                "padding": "0 !important",
                "background-color": "transparent",
                "border-bottom": "1px solid #E5E7EB",
                "margin": "0 0 1rem 0",
            },
            "icon": {"display": "none"},
            "nav-link": {
                "font-size": "0.95rem",
                "font-weight": "500",
                "text-align": "center",
                "margin": "0",
                "padding": "0.7rem 1rem",
                "color": "#4B5563",
                "border-radius": "0",
                "border-bottom": "3px solid transparent",
                "background-color": "transparent",
                "--hover-color": "#F4F5F7",
            },
            "nav-link-selected": {
                "background-color": "transparent",
                "color": "#C74634",
                "border-bottom": "3px solid #C74634",
                "font-weight": "600",
            },
        },
    )

    new_key = dict(zip(labels, keys))[selected]
    if new_key != st.session_state["active_page"]:
        st.session_state["active_page"] = new_key
    return st.session_state["active_page"]
