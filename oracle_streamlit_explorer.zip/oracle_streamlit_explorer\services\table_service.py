"""Orchestrates table metadata retrieval for the UI."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from db import data_queries as dq
from db import metadata_queries as mq


@dataclass
class TableBundle:
    overview: pd.DataFrame
    columns: pd.DataFrame
    constraints: pd.DataFrame
    indexes: pd.DataFrame
    fk_out: pd.DataFrame
    fk_in: pd.DataFrame


def load_table_bundle(env: str, owner: str, table: str) -> TableBundle:
    return TableBundle(
        overview=mq.table_overview(env, owner, table),
        columns=mq.table_columns(env, owner, table),
        constraints=mq.table_constraints(env, owner, table),
        indexes=mq.table_indexes(env, owner, table),
        fk_out=mq.foreign_keys_outgoing(env, owner, table),
        fk_in=mq.foreign_keys_incoming(env, owner, table),
    )


def find_tables(env: str, owner: str, pattern: str | None) -> pd.DataFrame:
    pattern = pattern.strip() if pattern else None
    if pattern == "":
        pattern = None
    return mq.list_tables(env, owner, pattern)


def preview(
    env: str,
    owner: str,
    table: str,
    *,
    limit: int,
    where_sql: str,
    binds: dict[str, Any],
    order_by: str | None,
    order_dir: str = "ASC",
):
    return dq.preview_rows(
        env, owner, table,
        limit=limit,
        where_sql=where_sql,
        binds=binds,
        order_by=order_by,
        order_dir=order_dir,
    )
