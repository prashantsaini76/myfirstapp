"""Live data queries with strict identifier validation + row caps."""
from __future__ import annotations

from typing import Any

import pandas as pd
import streamlit as st

from db.connection import run_query, run_query_timed
from utils.sql_validator import (
    MAX_PREVIEW_ROWS,
    assert_identifier,
    is_safe_select,
)


def preview_rows(
    env: str,
    owner: str,
    table: str,
    *,
    limit: int = 100,
    where_sql: str = "",
    binds: dict[str, Any] | None = None,
    order_by: str | None = None,
    order_dir: str = "ASC",
) -> tuple[pd.DataFrame, str, float]:
    assert_identifier(owner, kind="schema")
    assert_identifier(table, kind="table")
    limit = max(1, min(int(limit), MAX_PREVIEW_ROWS))
    binds = dict(binds or {})

    where_part = f"WHERE {where_sql}" if where_sql.strip() else ""
    order_part = ""
    if order_by:
        assert_identifier(order_by, kind="column")
        direction = "DESC" if str(order_dir).upper() == "DESC" else "ASC"
        order_part = f'ORDER BY "{order_by}" {direction}'

    sql = (
        f'SELECT * FROM "{owner}"."{table}" '
        f"{where_part} {order_part} "
        "FETCH FIRST :row_limit ROWS ONLY"
    )
    binds["row_limit"] = limit
    df, secs = run_query_timed(env, sql, binds)
    return df, sql, secs


def row_count(env: str, owner: str, table: str) -> int:
    assert_identifier(owner, kind="schema")
    assert_identifier(table, kind="table")
    df = run_query(env, f'SELECT COUNT(*) AS C FROM "{owner}"."{table}"')
    return int(df.iloc[0, 0])


def run_user_select(env: str, sql: str, *, max_rows: int = 5000) -> tuple[pd.DataFrame, float]:
    is_safe_select(sql, raise_on_error=True)
    return run_query_timed(env, sql, max_rows=max_rows)


# --------------------------------------------------------------- value search

def _coerce_for_like(value: str, mode: str) -> str:
    if mode == "starts":
        return f"{value}%"
    if mode == "ends":
        return f"%{value}"
    if mode == "contains":
        return f"%{value}%"
    return value  # exact


def find_value_columns(
    env: str,
    owner: str,
    table: str,
    *,
    value: str,
    columns: list[str],
    mode: str = "contains",        # exact | contains | starts | ends
    case_insensitive: bool = True,
    scan_limit: int = 100_000,
) -> tuple[pd.DataFrame, str, float]:
    """For each column, count rows where TO_CHAR(col) matches the value.

    Returns (df[COLUMN_NAME, HITS], generated_sql, elapsed_sec).
    Only columns with HITS > 0 are returned.
    """
    assert_identifier(owner, kind="schema")
    assert_identifier(table, kind="table")
    if not columns:
        raise ValueError("No columns selected.")
    for c in columns:
        assert_identifier(c, kind="column")

    use_like = mode != "exact"
    pattern = _coerce_for_like(value, mode)

    parts: list[str] = []
    for c in columns:
        if case_insensitive:
            col_expr = f'UPPER(TO_CHAR("{c}"))'
            rhs = "UPPER(:pat)" if use_like else "UPPER(:val)"
        else:
            col_expr = f'TO_CHAR("{c}")'
            rhs = ":pat" if use_like else ":val"
        cond = f"{col_expr} {'LIKE' if use_like else '='} {rhs}"
        # Replace single-quotes in column name for the literal label
        label = c.replace("'", "''")
        parts.append(
            f"SELECT '{label}' AS column_name, COUNT(*) AS hits "
            f'FROM (SELECT "{c}" FROM "{owner}"."{table}" '
            f"WHERE ROWNUM <= :scan_limit) WHERE {cond}"
        )

    sql = " UNION ALL ".join(parts)
    binds: dict[str, object] = {"scan_limit": int(scan_limit)}
    if use_like:
        binds["pat"] = pattern
    else:
        binds["val"] = value

    df, secs = run_query_timed(env, sql, binds)
    df = df[df["HITS"] > 0].sort_values("HITS", ascending=False).reset_index(drop=True)
    return df, sql, secs


# --------------------------------------------------------------- lookups


def load_lookup_pairs(
    env: str,
    owner: str,
    table: str,
    key_col: str,
    val_col: str,
    *,
    max_rows: int = 50_000,
) -> tuple[pd.DataFrame, float]:
    """Return DataFrame with CODE / MEANING columns from a reference table."""
    assert_identifier(owner, kind="schema")
    assert_identifier(table, kind="table")
    assert_identifier(key_col, kind="column")
    assert_identifier(val_col, kind="column")
    sql = (
        f'SELECT "{key_col}" AS code, "{val_col}" AS meaning '
        f'FROM "{owner}"."{table}" '
        f"FETCH FIRST :row_limit ROWS ONLY"
    )
    df, secs = run_query_timed(env, sql, {"row_limit": int(max_rows)})
    return df, secs


@st.cache_data(ttl=300, show_spinner=False)
def lookup_map(
    env: str, owner: str, table: str, key_col: str, val_col: str,
    *, max_rows: int = 50_000,
) -> dict[str, Any]:
    """Cached code -> meaning dictionary (keys forced to string for stable matching)."""
    df, _ = load_lookup_pairs(env, owner, table, key_col, val_col, max_rows=max_rows)
    if df.empty:
        return {}
    df = df.dropna(subset=["CODE"])
    return {str(k): v for k, v in zip(df["CODE"], df["MEANING"])}


def find_value_samples(
    env: str,
    owner: str,
    table: str,
    column: str,
    *,
    value: str,
    mode: str = "contains",
    case_insensitive: bool = True,
    sample_rows: int = 20,
    scan_limit: int = 100_000,
) -> tuple[pd.DataFrame, str, float]:
    """Return sample rows from the table where `column` matches the value."""
    assert_identifier(owner, kind="schema")
    assert_identifier(table, kind="table")
    assert_identifier(column, kind="column")

    use_like = mode != "exact"
    pattern = _coerce_for_like(value, mode)
    if case_insensitive:
        col_expr = f'UPPER(TO_CHAR("{column}"))'
        rhs = "UPPER(:pat)" if use_like else "UPPER(:val)"
    else:
        col_expr = f'TO_CHAR("{column}")'
        rhs = ":pat" if use_like else ":val"

    cond = f"{col_expr} {'LIKE' if use_like else '='} {rhs}"
    sql = (
        f'SELECT * FROM (SELECT t.* FROM "{owner}"."{table}" t '
        f"WHERE ROWNUM <= :scan_limit) WHERE {cond} "
        "FETCH FIRST :sample_rows ROWS ONLY"
    )
    binds: dict[str, object] = {
        "scan_limit": int(scan_limit),
        "sample_rows": int(sample_rows),
    }
    if use_like:
        binds["pat"] = pattern
    else:
        binds["val"] = value
    df, secs = run_query_timed(env, sql, binds)
    return df, sql, secs
