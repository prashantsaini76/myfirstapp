"""Sidebar: environment + schema selectors and connection status."""
from __future__ import annotations

import streamlit as st

from db import metadata_queries as mq
from db.connection import (
    connection_status,
    default_environment,
    list_environments,
)


def _pill(ok: bool, text: str) -> str:
    color = "#198754" if ok else "#B42318"
    bg = "#E7F4EC" if ok else "#FEE4E2"
    dot = "●"
    return (
        f'<div style="padding:6px 10px;border-radius:6px;background:{bg};'
        f'color:{color};font-size:0.85rem;font-weight:500;">'
        f'<span style="margin-right:6px;">{dot}</span>{text}</div>'
    )


def render() -> tuple[str | None, str]:
    """Returns (selected_schema_or_None, environment)."""
    with st.sidebar:
        st.markdown(
            "<div style='font-size:1.05rem;font-weight:600;margin-bottom:8px;'>"
            "Oracle Explorer</div>",
            unsafe_allow_html=True,
        )

        # ----- environment -----
        st.markdown("**Environment**")
        envs = list_environments()
        cur_env = st.session_state.get("environment") or default_environment()
        if cur_env not in envs:
            cur_env = envs[0]
        env = st.selectbox(
            "Environment", envs, index=envs.index(cur_env),
            label_visibility="collapsed",
        )
        if env != st.session_state.get("environment"):
            st.session_state["environment"] = env
            st.cache_data.clear()
            st.session_state["selected_schema"] = None

        # ----- connection -----
        ok, info = connection_status(env)
        st.markdown(
            _pill(ok, f"Connected" if ok else "Not connected"),
            unsafe_allow_html=True,
        )
        if not ok:
            with st.expander("Connection error"):
                st.code(info)
            st.stop()
        st.caption(info)

        st.divider()

        # ----- schema -----
        st.markdown("**Schema**")
        hide_system = st.toggle(
            "Hide system schemas",
            value=st.session_state.get("hide_system_schemas", False),
            key="hide_system_schemas",
            help="Hide Oracle-supplied internal schemas (SYS, MDSYS, XDB, APEX_*, …).",
        )
        schemas = mq.list_schemas(env, hide_system=hide_system)["OWNER"].tolist()
        if hide_system and not schemas:
            st.warning(
                "No user schemas found with this filter. "
                "Disable the toggle above to see all schemas."
            )
        prior = st.session_state.get("selected_schema")
        index = schemas.index(prior) if prior in schemas else None
        owner = st.selectbox(
            "Schema", schemas, index=index,
            placeholder="Select a schema…", label_visibility="collapsed",
        )
        st.session_state["selected_schema"] = owner

        st.divider()
        if st.button(
            "Refresh metadata cache",
            use_container_width=True,
            type="tertiary",
            key="refresh_cache_btn",
        ):
            st.cache_data.clear()
            st.toast("Metadata cache cleared.")
            st.rerun()

        st.caption("Read-only · SELECT-only enforced")
    return owner, env
