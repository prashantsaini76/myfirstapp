"""Oracle connection pools, one per named environment.

Environments are defined in `.streamlit/secrets.toml` under
`[environments.<NAME>]` (e.g. SIT_CR, SIT_PARTY, OAT, PROD).
Helpers always require an `env` argument so cache keys stay correct
when the user switches environments at runtime.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any, Mapping, Optional

import oracledb
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("oracle_explorer.db")


@dataclass(frozen=True)
class OracleConfig:
    name: str
    user: str
    password: str
    dsn: str
    min_pool: int = 1
    max_pool: int = 4
    increment: int = 1
    read_only_session: bool = True
    call_timeout_ms: int = 60_000

    def safe_user(self) -> str:
        if len(self.user) <= 2:
            return "*" * len(self.user)
        return f"{self.user[0]}{'*' * (len(self.user) - 2)}{self.user[-1]}"


def _read_env_block(name: str, block: Mapping[str, Any]) -> OracleConfig:
    return OracleConfig(
        name=name,
        user=block["user"],
        password=block["password"],
        dsn=block["dsn"],
        min_pool=int(block.get("min_pool", 1)),
        max_pool=int(block.get("max_pool", 4)),
        increment=int(block.get("increment", 1)),
        read_only_session=bool(block.get("read_only_session", True)),
        call_timeout_ms=int(block.get("call_timeout_ms", 60_000)),
    )


def _envs_from_secrets() -> dict[str, OracleConfig]:
    try:
        envs = st.secrets["environments"]  # type: ignore[index]
    except Exception:
        return {}
    return {name: _read_env_block(name, block) for name, block in envs.items()}


def _envs_from_env_vars() -> dict[str, OracleConfig]:
    """Fallback: single env via env vars, exposed as 'DEFAULT'."""
    user = os.getenv("ORACLE_USER")
    pwd = os.getenv("ORACLE_PASSWORD")
    dsn = os.getenv("ORACLE_DSN")
    if not (user and pwd and dsn):
        return {}
    return {
        "DEFAULT": OracleConfig(
            name="DEFAULT",
            user=user,
            password=pwd,
            dsn=dsn,
            min_pool=int(os.getenv("ORACLE_MIN_POOL", "1")),
            max_pool=int(os.getenv("ORACLE_MAX_POOL", "4")),
            read_only_session=os.getenv("ORACLE_READ_ONLY_SESSION", "true").lower() == "true",
            call_timeout_ms=int(os.getenv("ORACLE_CALL_TIMEOUT_MS", "60000")),
        )
    }


@st.cache_resource(show_spinner=False)
def _all_environments() -> dict[str, OracleConfig]:
    envs = _envs_from_secrets() or _envs_from_env_vars()
    if not envs:
        raise RuntimeError(
            "No Oracle environments configured. Define [environments.NAME] "
            "blocks in .streamlit/secrets.toml or set ORACLE_USER/PASSWORD/DSN env vars."
        )
    return envs


def list_environments() -> list[str]:
    return list(_all_environments().keys())


def default_environment() -> str:
    try:
        d = st.secrets.get("default_environment")  # type: ignore[attr-defined]
    except Exception:
        d = None
    envs = list_environments()
    if d and d in envs:
        return d
    return envs[0]


def load_config(env: str) -> OracleConfig:
    envs = _all_environments()
    if env not in envs:
        raise KeyError(f"Unknown environment: {env}")
    return envs[env]


def _on_acquire(conn: oracledb.Connection, _requested_tag: str) -> None:
    try:
        with conn.cursor() as cur:
            cur.execute("ALTER SESSION SET READ ONLY")
    except Exception as exc:
        log.debug("Could not set READ ONLY session: %s", exc)


@st.cache_resource(show_spinner="Connecting to Oracle…")
def get_pool(env: str) -> oracledb.ConnectionPool:
    cfg = load_config(env)
    kwargs: dict[str, Any] = dict(
        user=cfg.user,
        password=cfg.password,
        dsn=cfg.dsn,
        min=cfg.min_pool,
        max=cfg.max_pool,
        increment=cfg.increment,
        getmode=oracledb.POOL_GETMODE_WAIT,
        timeout=300,
    )
    if cfg.read_only_session:
        kwargs["session_callback"] = _on_acquire
    pool = oracledb.create_pool(**kwargs)
    log.info("Oracle pool [%s] created for %s@%s", env, cfg.safe_user(), cfg.dsn)
    return pool


def connection_status(env: str) -> tuple[bool, str]:
    try:
        cfg = load_config(env)
        pool = get_pool(env)
        with pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM DUAL")
                cur.fetchone()
        return True, f"{cfg.safe_user()} @ {cfg.dsn}"
    except Exception as exc:
        return False, str(exc)


def run_query(
    env: str,
    sql: str,
    params: Optional[Mapping[str, Any]] = None,
    *,
    max_rows: Optional[int] = None,
) -> pd.DataFrame:
    cfg = load_config(env)
    pool = get_pool(env)
    with pool.acquire() as conn:
        if cfg.call_timeout_ms:
            try:
                conn.call_timeout = cfg.call_timeout_ms
            except Exception:
                pass
        with conn.cursor() as cur:
            cur.execute(sql, params or {})
            cols = [d[0] for d in cur.description] if cur.description else []
            rows = cur.fetchmany(max_rows) if max_rows else cur.fetchall()
    return pd.DataFrame(rows, columns=cols)


def run_query_timed(
    env: str,
    sql: str,
    params: Optional[Mapping[str, Any]] = None,
    *,
    max_rows: Optional[int] = None,
) -> tuple[pd.DataFrame, float]:
    import time

    t0 = time.perf_counter()
    df = run_query(env, sql, params, max_rows=max_rows)
    return df, time.perf_counter() - t0
