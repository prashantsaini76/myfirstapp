"""Find columns by keyword across tables and schemas."""
from __future__ import annotations

import streamlit as st

from components.data_grid import interactive_grid
from db import metadata_queries as mq

DEFAULT_LIMIT = 2000


def render(env: str, owner: str | None) -> None:
    st.title("Column Search")
    st.caption(
        f"{env} · Find which tables contain a column matching a keyword "
        "(e.g. USER_ID, customer name, account)."
    )

    with st.container(border=True):
        c1, c2, c3 = st.columns([4, 2, 1])
        keyword = c1.text_input(
            "Keyword",
            placeholder="USER_ID, customer name, account…",
            help="Words are split on spaces, underscores and dashes. "
                 "Each token is matched as a substring (case-insensitive).",
        )
        scope_options = ["Current schema"] + (["All schemas"] if owner else ["All schemas"])
        scope_default = 0 if owner else 1
        scope = c2.radio(
            "Scope",
            scope_options,
            index=scope_default,
            horizontal=True,
            disabled=owner is None,
            help=("Limit to the schema selected in the sidebar, or search "
                  "every schema you can see.") if owner else
                 "No schema selected — searching all schemas.",
        )
        c3.markdown("<div style='height:1.85rem'></div>", unsafe_allow_html=True)
        run = c3.button("Search", type="primary", use_container_width=True)

        c4, c5 = st.columns([2, 4])
        match_all = c4.toggle(
            "Match all tokens",
            value=False,
            help="OFF: column name contains ANY token. ON: must contain ALL tokens.",
        )
        limit = c5.slider("Max results", 100, 10_000, DEFAULT_LIMIT, step=100)

    if not run:
        st.info("Enter a keyword and click **Search**.")
        return

    if not keyword or not keyword.strip():
        st.warning("Please enter a keyword.")
        return

    target_owner = owner if (scope == "Current schema" and owner) else None

    with st.spinner("Searching columns…"):
        df = mq.search_columns(
            env, keyword,
            owner=target_owner,
            match_all_tokens=match_all,
            limit=int(limit),
            hide_system=bool(st.session_state.get("hide_system_schemas", False)),
        )

    if df.empty:
        st.warning(
            f"No columns matched '{keyword}'"
            + (f" in {target_owner}." if target_owner else " in any schema.")
        )
        return

    # ----- summary -----
    distinct_cols = df["COLUMN_NAME"].nunique()
    distinct_tables = df.groupby(["OWNER", "TABLE_NAME"]).ngroups
    distinct_schemas = df["OWNER"].nunique()
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Matches", f"{len(df):,}")
    k2.metric("Distinct columns", f"{distinct_cols:,}")
    k3.metric("Distinct tables", f"{distinct_tables:,}")
    k4.metric("Schemas", f"{distinct_schemas:,}")
    if len(df) >= limit:
        st.warning(
            f"Result truncated at {limit:,}. Increase 'Max results' or refine the keyword."
        )

    tabs = st.tabs(["By column", "All matches"])

    with tabs[0]:
        grouped = (
            df.groupby("COLUMN_NAME")
              .agg(
                  TABLES=("TABLE_NAME", "nunique"),
                  SCHEMAS=("OWNER", "nunique"),
                  EXAMPLE_TABLE=("TABLE_NAME", "first"),
                  EXAMPLE_SCHEMA=("OWNER", "first"),
                  DATA_TYPES=("DATA_TYPE", lambda s: ", ".join(sorted(set(s.dropna())))),
              )
              .reset_index()
              .sort_values("TABLES", ascending=False)
        )
        interactive_grid(
            grouped, key="col_search_grouped",
            download_basename=f"column_search_{keyword}_grouped",
            height=420, show_search=True,
        )

    with tabs[1]:
        interactive_grid(
            df, key="col_search_full",
            download_basename=f"column_search_{keyword}",
            height=520, show_search=True,
        )
