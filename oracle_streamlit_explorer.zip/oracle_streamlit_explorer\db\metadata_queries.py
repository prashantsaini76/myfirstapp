"""Read-only Oracle data dictionary queries.

Every public function takes `env` as its first argument so Streamlit's
cache invalidates correctly when the user switches environments.
"""
from __future__ import annotations

import pandas as pd
import streamlit as st

from db.connection import run_query
from utils.sql_validator import assert_identifier

# Oracle-supplied / internal schemas we never want to expose in the UI.
SYSTEM_SCHEMAS: tuple[str, ...] = (
    "ANONYMOUS", "APEX_PUBLIC_USER", "APPQOSSYS", "AUDSYS",
    "CTXSYS", "DBSFWUSER", "DBSNMP", "DGPDB_INT", "DIP",
    "DVF", "DVSYS", "EXFSYS", "FLOWS_FILES", "GGSYS",
    "GSMADMIN_INTERNAL", "GSMCATUSER", "GSMROOTUSER", "GSMUSER",
    "LBACSYS", "MDDATA", "MDSYS", "OJVMSYS", "OLAPSYS",
    "ORACLE_OCM", "ORDDATA", "ORDPLUGINS", "ORDSYS", "OUTLN",
    "PDBADMIN", "REMOTE_SCHEDULER_AGENT", "SI_INFORMTN_SCHEMA",
    "SPATIAL_CSW_ADMIN_USR", "SPATIAL_WFS_ADMIN_USR",
    "SYS", "SYS$UMF", "SYSBACKUP", "SYSDG", "SYSKM", "SYSRAC",
    "SYSTEM", "SYSAUX", "WMSYS", "XDB", "XS$NULL",
)

# Literal SQL fragment for use inside NOT IN (...). Built from a static
# allow-list above, so no injection risk.
_SYS_LIST_SQL = ", ".join(f"'{s}'" for s in SYSTEM_SCHEMAS)
# Also catch every APEX_* and APEX$* schema regardless of version.
_NOT_SYSTEM = (
    f"username NOT IN ({_SYS_LIST_SQL}) "
    "AND username NOT LIKE 'APEX\\_%' ESCAPE '\\' "
    "AND username NOT LIKE 'APEX$%'"
)
_OWNER_NOT_SYSTEM = _NOT_SYSTEM.replace("username", "owner")


# ---------- dashboard KPIs ----------

@st.cache_data(ttl=600, show_spinner=False)
def kpi_counts(env: str, hide_system: bool = False) -> dict[str, int]:
    user_filter = f"WHERE {_NOT_SYSTEM}" if hide_system else ""
    owner_filter = f"WHERE {_OWNER_NOT_SYSTEM}" if hide_system else ""
    sql = f"""
        SELECT
          (SELECT COUNT(*) FROM all_users       {user_filter})  AS schemas,
          (SELECT COUNT(*) FROM all_tables      {owner_filter}) AS tables,
          (SELECT COUNT(*) FROM all_views       {owner_filter}) AS views,
          (SELECT COUNT(*) FROM all_constraints {owner_filter}) AS constraints,
          (SELECT COUNT(*) FROM all_indexes     {owner_filter}) AS indexes
        FROM dual
    """
    df = run_query(env, sql)
    return {k.lower(): int(v) for k, v in df.iloc[0].items()}


# ---------- schema / table lists ----------

@st.cache_data(ttl=600, show_spinner=False)
def list_schemas(env: str, hide_system: bool = False) -> pd.DataFrame:
    where = f"WHERE {_NOT_SYSTEM}" if hide_system else ""
    return run_query(env, f"SELECT username AS owner FROM all_users {where} ORDER BY username")


@st.cache_data(ttl=600, show_spinner=False)
def list_tables(env: str, owner: str, name_pattern: str | None = None) -> pd.DataFrame:
    assert_identifier(owner, kind="schema")
    sql = """
        SELECT t.owner,
               t.table_name,
               t.num_rows,
               t.last_analyzed,
               t.tablespace_name,
               t.status,
               c.comments
          FROM all_tables  t
          LEFT JOIN all_tab_comments c
            ON c.owner = t.owner AND c.table_name = t.table_name
         WHERE t.owner = :owner
           AND (:pattern IS NULL OR t.table_name LIKE :pattern ESCAPE '\\')
         ORDER BY t.table_name
    """
    return run_query(env, sql, {"owner": owner, "pattern": name_pattern})


@st.cache_data(ttl=600, show_spinner=False)
def list_views(env: str, owner: str) -> pd.DataFrame:
    assert_identifier(owner, kind="schema")
    return run_query(
        env,
        "SELECT owner, view_name, text_length FROM all_views "
        "WHERE owner = :owner ORDER BY view_name",
        {"owner": owner},
    )


# ---------- table detail ----------

@st.cache_data(ttl=600, show_spinner=False)
def table_overview(env: str, owner: str, table: str) -> pd.DataFrame:
    assert_identifier(owner, kind="schema")
    assert_identifier(table, kind="table")
    sql = """
        SELECT t.owner, t.table_name, t.num_rows, t.blocks, t.avg_row_len,
               t.last_analyzed, t.tablespace_name, t.status, t.temporary,
               t.partitioned, c.comments
          FROM all_tables t
          LEFT JOIN all_tab_comments c
            ON c.owner = t.owner AND c.table_name = t.table_name
         WHERE t.owner = :owner AND t.table_name = :tname
    """
    return run_query(env, sql, {"owner": owner, "tname": table})


@st.cache_data(ttl=600, show_spinner=False)
def table_columns(env: str, owner: str, table: str) -> pd.DataFrame:
    sql = """
        SELECT c.column_id,
               c.column_name,
               c.data_type,
               c.data_length,
               c.data_precision,
               c.data_scale,
               c.nullable,
               c.data_default,
               cc.comments
          FROM all_tab_columns c
          LEFT JOIN all_col_comments cc
            ON cc.owner = c.owner
           AND cc.table_name = c.table_name
           AND cc.column_name = c.column_name
         WHERE c.owner = :owner AND c.table_name = :tname
         ORDER BY c.column_id
    """
    return run_query(env, sql, {"owner": owner, "tname": table})


@st.cache_data(ttl=600, show_spinner=False)
def table_constraints(env: str, owner: str, table: str | None = None) -> pd.DataFrame:
    sql = """
        SELECT c.owner,
               c.table_name,
               c.constraint_name,
               c.constraint_type,
               cc.column_name,
               cc.position,
               c.search_condition,
               c.r_owner,
               rc.table_name      AS r_table_name,
               rcc.column_name    AS r_column_name,
               c.status
          FROM all_constraints c
          LEFT JOIN all_cons_columns cc
            ON cc.owner = c.owner AND cc.constraint_name = c.constraint_name
          LEFT JOIN all_constraints rc
            ON rc.owner = c.r_owner AND rc.constraint_name = c.r_constraint_name
          LEFT JOIN all_cons_columns rcc
            ON rcc.owner = rc.owner
           AND rcc.constraint_name = rc.constraint_name
           AND rcc.position = cc.position
         WHERE c.owner = :owner
           AND (:tname IS NULL OR c.table_name = :tname)
         ORDER BY c.table_name, c.constraint_name, cc.position
    """
    return run_query(env, sql, {"owner": owner, "tname": table})


@st.cache_data(ttl=600, show_spinner=False)
def table_indexes(env: str, owner: str, table: str) -> pd.DataFrame:
    sql = """
        SELECT i.index_name,
               i.index_type,
               i.uniqueness,
               i.status,
               i.tablespace_name,
               ic.column_name,
               ic.column_position,
               ic.descend
          FROM all_indexes i
          JOIN all_ind_columns ic
            ON ic.index_owner = i.owner AND ic.index_name = i.index_name
         WHERE i.table_owner = :owner AND i.table_name = :tname
         ORDER BY i.index_name, ic.column_position
    """
    return run_query(env, sql, {"owner": owner, "tname": table})


@st.cache_data(ttl=600, show_spinner=False)
def foreign_keys_outgoing(env: str, owner: str, table: str) -> pd.DataFrame:
    sql = """
        SELECT c.constraint_name,
               c.table_name        AS child_table,
               cc.column_name      AS child_column,
               rc.owner            AS parent_owner,
               rc.table_name       AS parent_table,
               rcc.column_name     AS parent_column
          FROM all_constraints c
          JOIN all_cons_columns cc
            ON cc.owner = c.owner AND cc.constraint_name = c.constraint_name
          JOIN all_constraints rc
            ON rc.owner = c.r_owner AND rc.constraint_name = c.r_constraint_name
          JOIN all_cons_columns rcc
            ON rcc.owner = rc.owner
           AND rcc.constraint_name = rc.constraint_name
           AND rcc.position = cc.position
         WHERE c.constraint_type = 'R'
           AND c.owner = :owner
           AND c.table_name = :tname
         ORDER BY c.constraint_name, cc.position
    """
    return run_query(env, sql, {"owner": owner, "tname": table})


@st.cache_data(ttl=600, show_spinner=False)
def foreign_keys_incoming(env: str, owner: str, table: str) -> pd.DataFrame:
    sql = """
        SELECT c.constraint_name,
               c.owner             AS child_owner,
               c.table_name        AS child_table,
               cc.column_name      AS child_column,
               rc.table_name       AS parent_table,
               rcc.column_name     AS parent_column
          FROM all_constraints c
          JOIN all_cons_columns cc
            ON cc.owner = c.owner AND cc.constraint_name = c.constraint_name
          JOIN all_constraints rc
            ON rc.owner = c.r_owner AND rc.constraint_name = c.r_constraint_name
          JOIN all_cons_columns rcc
            ON rcc.owner = rc.owner
           AND rcc.constraint_name = rc.constraint_name
           AND rcc.position = cc.position
         WHERE c.constraint_type = 'R'
           AND rc.owner = :owner
           AND rc.table_name = :tname
         ORDER BY c.owner, c.table_name, cc.position
    """
    return run_query(env, sql, {"owner": owner, "tname": table})


@st.cache_data(ttl=600, show_spinner=False)
def all_constraints_in_schema(env: str, owner: str) -> pd.DataFrame:
    return table_constraints(env, owner, None)


# ---------- column search ----------

@st.cache_data(ttl=600, show_spinner=False)
def search_columns(
    env: str,
    keyword: str,
    *,
    owner: str | None = None,
    match_all_tokens: bool = False,
    limit: int = 2000,
    hide_system: bool = False,
) -> pd.DataFrame:
    """Find columns whose name matches `keyword`.

    The keyword is split on whitespace, '_', '-' to allow keyword-style search.
    - match_all_tokens=False (default): column name contains ANY token (OR).
    - match_all_tokens=True:            column name contains ALL tokens (AND).

    Always case-insensitive. Empty token list -> empty result.
    """
    import re

    tokens = [t for t in re.split(r"[\s_\-]+", (keyword or "").strip()) if t]
    if not tokens:
        return pd.DataFrame()

    # Validate token chars: only allow safe identifier-like fragments.
    safe = re.compile(r"^[A-Za-z0-9$#]+$")
    tokens = [t for t in tokens if safe.match(t)]
    if not tokens:
        return pd.DataFrame()

    binds: dict[str, object] = {"owner": owner, "row_limit": int(limit)}
    conds: list[str] = []
    for i, tok in enumerate(tokens):
        key = f"tok{i}"
        binds[key] = f"%{tok.upper()}%"
        conds.append(f"UPPER(c.column_name) LIKE :{key}")
    joiner = " AND " if match_all_tokens else " OR "
    where_tokens = "(" + joiner.join(conds) + ")"

    system_filter = ""
    if hide_system:
        not_system = _OWNER_NOT_SYSTEM.replace("owner", "c.owner")
        system_filter = f"AND (:owner IS NOT NULL OR ({not_system}))"
    sql = f"""
        SELECT c.owner,
               c.table_name,
               c.column_name,
               c.data_type,
               c.data_length,
               c.nullable,
               cc.comments
          FROM all_tab_columns c
          LEFT JOIN all_col_comments cc
            ON  cc.owner = c.owner
            AND cc.table_name = c.table_name
            AND cc.column_name = c.column_name
         WHERE (:owner IS NULL OR c.owner = :owner)
           {system_filter}
           AND {where_tokens}
         ORDER BY c.owner, c.column_name, c.table_name
         FETCH FIRST :row_limit ROWS ONLY
    """
    return run_query(env, sql, binds)
