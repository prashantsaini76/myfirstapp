"""Read-only SQL console with allow-list validator."""
from __future__ import annotations

import streamlit as st

from components.data_grid import interactive_grid
from db.data_queries import run_user_select
from utils.sql_validator import UnsafeSQLError

DEFAULT_SQL = "SELECT * FROM all_tables FETCH FIRST 50 ROWS ONLY"


def render(env: str, owner: str | None) -> None:
    st.title("SQL Console")
    st.caption(
        f"{env} · Read-only. Only single-statement SELECT or WITH queries are accepted."
    )

    sql = st.text_area(
        "SQL",
        value=st.session_state.get("console_sql", DEFAULT_SQL),
        height=200,
        key="console_sql_input",
        label_visibility="collapsed",
    )
    c1, c2, _ = st.columns([1, 1, 4])
    max_rows = c1.number_input("Max rows", 1, 10_000, 500, step=100)
    c2.markdown("<div style='height:1.85rem'></div>", unsafe_allow_html=True)
    run = c2.button("Run query", type="primary", use_container_width=True)

    if run:
        try:
            with st.spinner("Executing query…"):
                df, secs = run_user_select(env, sql, max_rows=int(max_rows))
            st.session_state["console_sql"] = sql
            st.session_state["console_result"] = {"df": df, "secs": secs}
        except UnsafeSQLError as exc:
            st.error(f"Rejected by validator: {exc}")
            st.session_state.pop("console_result", None)
        except Exception as exc:
            st.error(f"Query failed: {exc}")
            st.session_state.pop("console_result", None)

    cached = st.session_state.get("console_result")
    if cached:
        st.success(f"{len(cached['df']):,} row(s) returned in {cached['secs']:.2f}s.")
        interactive_grid(cached["df"], key="console_results",
                         download_basename="query_results", height=480)
