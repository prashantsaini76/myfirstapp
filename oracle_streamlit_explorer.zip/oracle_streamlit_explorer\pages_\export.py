"""Bulk export."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from components.cards import require_schema
from db import metadata_queries as mq
from services.export_service import df_to_csv_bytes, df_to_xlsx_bytes, workbook_bytes


def _build_full_docs(env: str, owner: str) -> dict[str, pd.DataFrame]:
    tables = mq.list_tables(env, owner)
    constraints = mq.all_constraints_in_schema(env, owner)

    columns_frames: list[pd.DataFrame] = []
    indexes_frames: list[pd.DataFrame] = []
    rel_frames: list[pd.DataFrame] = []
    for t in tables["TABLE_NAME"]:
        cdf = mq.table_columns(env, owner, t)
        cdf.insert(0, "TABLE_NAME", t)
        columns_frames.append(cdf)
        idf = mq.table_indexes(env, owner, t)
        idf.insert(0, "TABLE_NAME", t)
        indexes_frames.append(idf)
        fout = mq.foreign_keys_outgoing(env, owner, t)
        if not fout.empty:
            rel_frames.append(fout)

    return {
        "Tables": tables,
        "Columns": pd.concat(columns_frames, ignore_index=True) if columns_frames else pd.DataFrame(),
        "Constraints": constraints,
        "Indexes": pd.concat(indexes_frames, ignore_index=True) if indexes_frames else pd.DataFrame(),
        "Relationships": pd.concat(rel_frames, ignore_index=True) if rel_frames else pd.DataFrame(),
    }


def _dl(df: pd.DataFrame, base: str, key: str) -> None:
    c1, c2 = st.columns(2)
    c1.download_button("Download CSV", df_to_csv_bytes(df),
                       file_name=f"{base}.csv", mime="text/csv",
                       use_container_width=True, key=f"{key}_csv",
                       disabled=df.empty)
    c2.download_button("Download Excel", df_to_xlsx_bytes(df, sheet_name=base[:31]),
                       file_name=f"{base}.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                       use_container_width=True, key=f"{key}_xlsx",
                       disabled=df.empty)


def render(env: str, owner: str | None) -> None:
    if not require_schema(owner):
        return

    st.title("Export")
    st.caption(f"{env} · {owner}")

    st.subheader("Table list")
    with st.spinner("Loading tables…"):
        tables_df = mq.list_tables(env, owner)
    _dl(tables_df, f"{owner}_tables", "exp_tables")

    st.subheader("All constraints")
    with st.spinner("Loading constraints…"):
        cons_df = mq.all_constraints_in_schema(env, owner)
    _dl(cons_df, f"{owner}_constraints", "exp_cons")

    st.divider()
    st.subheader("Full schema documentation")
    st.caption(
        "Multi-sheet workbook: Tables, Columns, Constraints, Indexes, Relationships. "
        "May take a minute on large schemas."
    )
    if st.button("Build documentation workbook", type="primary"):
        with st.spinner("Collecting metadata…"):
            sheets = _build_full_docs(env, owner)
        data = workbook_bytes(sheets)
        st.success(
            "Workbook ready: "
            + ", ".join(f"{k} ({len(v):,})" for k, v in sheets.items())
        )
        st.download_button(
            "Download workbook",
            data=data,
            file_name=f"{owner}_documentation.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )
