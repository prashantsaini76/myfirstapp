"""Oracle Streamlit Explorer — application entrypoint.

Run with:
    streamlit run app.py
"""
from __future__ import annotations

import logging

import streamlit as st

from components import sidebar, topnav
from pages_ import (
    column_search as p_column_search,
    constraints as p_constraints,
    dashboard as p_dashboard,
    export as p_export,
    lookups as p_lookups,
    relationships as p_relationships,
    sql_console as p_sql_console,
    tables as p_tables,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s: %(message)s",
)

st.set_page_config(
    page_title="Oracle Explorer",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .block-container {padding-top: 2rem; padding-bottom: 2rem; max-width: 1400px;}
      h1 {font-size: 1.6rem !important; margin-bottom: 0.2rem;}
      h2 {font-size: 1.2rem !important;}
      h3 {font-size: 1.05rem !important;}
      [data-testid="stMetricValue"] {font-size: 1.5rem;}
      [data-testid="stMetricLabel"] {font-weight: 500; color: #555;}
      section[data-testid="stSidebar"] {background: #FAFBFC;}
      div[data-baseweb="select"] > div {border-radius: 6px;}
      .stButton > button {border-radius: 6px;}
      [data-testid="stTabs"] button {font-weight: 500;}
    </style>
    """,
    unsafe_allow_html=True,
)

PAGES = {
    "dashboard":     p_dashboard.render,
    "tables":        p_tables.render,
    "column_search": p_column_search.render,
    "lookups":       p_lookups.render,
    "constraints":   p_constraints.render,
    "relationships": p_relationships.render,
    "sql_console":   p_sql_console.render,
    "export":        p_export.render,
}


def main() -> None:
    owner, env = sidebar.render()
    page_key = topnav.render()
    render_fn = PAGES.get(page_key, p_dashboard.render)
    try:
        render_fn(env, owner)
    except Exception as exc:
        st.error(f"Page failed: {exc}")
        with st.expander("Traceback"):
            import traceback
            st.code(traceback.format_exc())


if __name__ == "__main__":
    main()
