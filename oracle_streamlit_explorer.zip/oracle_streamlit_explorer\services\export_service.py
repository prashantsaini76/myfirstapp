"""DataFrame -> CSV / XLSX byte buffers for st.download_button."""
from __future__ import annotations

import io
from typing import Mapping

import pandas as pd


def df_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")


def df_to_xlsx_bytes(df: pd.DataFrame, sheet_name: str = "Sheet1") -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as xl:
        df.to_excel(xl, index=False, sheet_name=sheet_name[:31] or "Sheet1")
    return buf.getvalue()


def workbook_bytes(sheets: Mapping[str, pd.DataFrame]) -> bytes:
    """Build a multi-sheet xlsx from a {sheet_name: df} mapping."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as xl:
        wrote = False
        for name, df in sheets.items():
            safe = (name or "Sheet")[:31]
            (df if not df.empty else pd.DataFrame({"_empty_": []})).to_excel(
                xl, index=False, sheet_name=safe
            )
            wrote = True
        if not wrote:
            pd.DataFrame().to_excel(xl, index=False, sheet_name="Empty")
    return buf.getvalue()
