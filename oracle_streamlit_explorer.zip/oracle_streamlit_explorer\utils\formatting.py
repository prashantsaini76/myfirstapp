"""Tiny display helpers."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import pandas as pd


def humanize_int(n: Any) -> str:
    try:
        return f"{int(n):,}"
    except Exception:
        return "—"


def humanize_dt(v: Any) -> str:
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M")
    return "—" if v is None or pd.isna(v) else str(v)


def nullable_label(flag: str | None) -> str:
    if flag is None:
        return "—"
    return "Yes" if flag.upper() == "Y" else "No"


CONSTRAINT_TYPE_LABEL = {
    "P": "Primary Key",
    "R": "Foreign Key",
    "U": "Unique",
    "C": "Check",
    "V": "View Check",
    "O": "View Read-Only",
}


def constraint_label(code: str | None) -> str:
    if not code:
        return "—"
    return CONSTRAINT_TYPE_LABEL.get(code.upper(), code)
