# Oracle Streamlit Explorer

A read-only, enterprise-grade Oracle Database explorer built with Streamlit.
Designed for developers, testers, support engineers, and analysts who need to
inspect schemas, tables, columns, constraints, indexes, relationships, and
sample data — without writing SQL.

---

## Features

- Multi-environment connection switcher (e.g. `SIT_CR`, `SIT_PARTY`, `OAT`, `PROD`).
- Horizontal top navigation (Dashboard, Table Explorer, Column Search, Code Lookups, Constraints, Relationships, SQL Console, Export).
- KPI dashboard (schemas / tables / views / constraints / indexes).
- Table Explorer with searchable dropdown of all tables, plus a 6-tab detail view
  (Overview / Columns / Constraints / Indexes / Data Preview / Find Value / Relationships).
- Structured filter builder for Data Preview (column · operator · value),
  generated SQL panel, CSV/Excel export.
- **Code Lookups** — turn reference tables (`CDORGTP`, `REFCOUNTRY`, …) into
  reusable code→meaning maps. Decode codes inline in Data Preview or via the
  paste-and-decode tab.
- **Find Value** — given a table and a value, see which columns contain it.
- **Column Search** — find tables that contain a given column name (with fuzzy
  token-based matching).
- Relationship diagram (Graphviz, with PK/FK column cards inside each node).
- SQL Console with allow-list validator (single-statement SELECT / WITH only).
- Multi-sheet documentation workbook export.
- Hide-system-schemas toggle in the sidebar.

---

## Prerequisites

- **Python 3.10+** (recommended 3.11 or 3.12). Download from <https://www.python.org/downloads/>.
- **Oracle Database** reachable over TCP/IP. No Oracle Instant Client needed —
  `python-oracledb` runs in thin mode by default.
- **Graphviz binary** on `PATH` (for the Relationships diagram). Install from
  <https://graphviz.org/download/>. Optional but recommended.

---

## Quick start

Open a terminal in the unzipped project folder, then:

### Windows (PowerShell)

```powershell
# 1. Create and activate a virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# 2. Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# 3. Configure database credentials
#    (see "Configuration" section below)
copy .streamlit\secrets.toml.example .streamlit\secrets.toml
notepad .streamlit\secrets.toml

# 4. Run
streamlit run app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt

cp .streamlit/secrets.toml.example .streamlit/secrets.toml
nano .streamlit/secrets.toml       # or vim / any editor

streamlit run app.py
```

The app opens at <http://localhost:8501> automatically.

> If `python` resolves to Python 2 on Linux/macOS, use `python3` explicitly.
> If `Activate.ps1` is blocked on Windows, run
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once, or use
> `.\.venv\Scripts\activate.bat` from cmd instead.

---

## Configuration

Credentials are loaded from `.streamlit/secrets.toml`. Each `[environments.NAME]`
block becomes a selectable entry in the sidebar's **Environment** picker.

Example:

```toml
default_environment = "SIT_CR"

[environments.SIT_CR]
user = "your_readonly_user"
password = "your_password"
dsn = "host:1521/service_name"
min_pool = 1
max_pool = 4
read_only_session = true   # try ALTER SESSION SET READ ONLY on every checkout
call_timeout_ms = 60000

[environments.PROD]
user = "..."
password = "..."
dsn = "prod-db.example.com:1521/PRODPDB1"
```

DSN format is `host:port/service_name` (standard Oracle Easy Connect).

Alternative: set environment variables (`ORACLE_USER`, `ORACLE_PASSWORD`,
`ORACLE_DSN`) or copy `.env.example` to `.env`. Multi-environment requires
`secrets.toml` though.

---

## Project layout

```
oracle_streamlit_explorer/
├── app.py                    # entrypoint, page dispatcher, global CSS
├── requirements.txt
├── README.md
├── .env.example
├── .streamlit/
│   ├── config.toml
│   └── secrets.toml.example
├── db/
│   ├── connection.py         # pooled python-oracledb, multi-env config
│   ├── metadata_queries.py   # ALL_TABLES, ALL_TAB_COLUMNS, ALL_CONSTRAINTS, …
│   └── data_queries.py       # preview, row count, validated user SELECT,
│                             # find-value, lookup loaders
├── services/                 # business logic (no Streamlit imports)
├── components/               # sidebar, topnav, KPI cards, reusable data grid
├── pages_/                   # one render(env, owner) per page
└── utils/                    # SQL allow-list validator, filter builder,
                              # formatting helpers
```

---

## Security model

| Layer | Mechanism |
|---|---|
| Driver | `python-oracledb` pool with `session_callback` issuing `ALTER SESSION SET READ ONLY` (configurable). |
| Identifiers | All schema / table / column names spliced into SQL pass `assert_identifier` (`^[A-Za-z][A-Za-z0-9_$#]{0,127}$`). |
| Bind variables | All values are bound — never concatenated into SQL. |
| User filters | Structured filter builder generates parameterised WHERE; raw textboxes removed. |
| SQL Console | `sqlparse` AST check rejects anything that isn't a single `SELECT` / `WITH`; deny-list scan blocks DML/DDL/PLSQL keywords. |
| Row caps | UI cap of 10 000 rows; queries use `FETCH FIRST :n ROWS ONLY`. |
| Logging | Passwords never logged; user shown masked in sidebar. |

---

## Troubleshooting

- **`ModuleNotFoundError: No module named 'streamlit_option_menu'`**  
  Run `pip install -r requirements.txt` again inside the venv.
- **`DPI-1047: ... cannot locate ... Oracle Client library`**  
  Make sure `oracledb >= 2.2` is installed; thin mode is the default and does
  not require Instant Client. Only relevant if someone forced thick mode.
- **`ORA-01017: invalid username/password`**  
  Verify the `[environments.X]` block in `.streamlit/secrets.toml`.
- **Schema dropdown is empty**  
  Either the user lacks privileges on `ALL_USERS`, or you've turned on
  *Hide system schemas* and no non-system schemas exist. Disable the toggle.
- **Relationship diagram error: `failed to execute 'dot'`**  
  Install the Graphviz binary from <https://graphviz.org/download/> and ensure
  `dot` is on `PATH`.

---

## Updating

To pull in new dependencies after editing the code:

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Click **Refresh metadata cache** in the sidebar after schema/table changes in
the underlying database — metadata queries are cached for 10 minutes.

---

## License

Internal use. No external license bundled.
