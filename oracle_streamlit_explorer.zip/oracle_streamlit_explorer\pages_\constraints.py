"""Constraint browser across an entire schema."""
from __future__ import annotations

import streamlit as st

from components.cards import require_schema
from components.data_grid import interactive_grid
from services.constraint_service import constraints_for_schema

TYPE_LABELS = {
    "P": "Primary Key",
    "R": "Foreign Key",
    "U": "Unique",
    "C": "Check",
    "V": "View Check",
    "O": "View Read-Only",
}


def render(env: str, owner: str | None) -> None:
    if not require_schema(owner):
        return

    st.title("Constraints")
    st.caption(f"{env} · {owner}")

    c1, c2, c3 = st.columns(3)
    types = c1.multiselect(
        "Types",
        list(TYPE_LABELS.keys()),
        default=list(TYPE_LABELS.keys()),
        format_func=lambda c: TYPE_LABELS[c],
    )
    table_filter = c2.text_input("Filter by table name")
    name_filter = c3.text_input("Filter by constraint name")

    with st.spinner(f"Loading constraints from {owner}…"):
        df = constraints_for_schema(
            env, owner,
            table_filter=table_filter or None,
            type_filter=types or None,
            name_filter=name_filter or None,
        )
    if df.empty:
        st.info("No constraints match.")
        return

    display = df[
        ["TABLE_NAME", "CONSTRAINT_NAME", "TYPE_LABEL", "COLUMN_NAME",
         "POSITION", "R_TABLE_NAME", "R_COLUMN_NAME",
         "SEARCH_CONDITION", "STATUS"]
    ].rename(columns={
        "TYPE_LABEL": "TYPE",
        "R_TABLE_NAME": "REFERENCED_TABLE",
        "R_COLUMN_NAME": "REFERENCED_COLUMN",
    })
    interactive_grid(display, key="cons_browser",
                     download_basename=f"{owner}_constraints", height=560)
