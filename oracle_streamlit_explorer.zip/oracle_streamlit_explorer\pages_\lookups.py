"""Code Lookups.

Solves the "go to a reference table to find what code X means" problem:
 - Browse: open any reference table, pick key/value columns, see the full map.
 - Save: keep a named lookup in session_state for reuse.
 - Decode: paste a list of codes; get meanings instantly.
 - Saved lookups can also be applied to Data Preview results (see Tables page).
"""
from __future__ import annotations

import pandas as pd
import streamlit as st

from components.data_grid import interactive_grid
from db import data_queries as dq
from db import metadata_queries as mq

LOOKUPS_KEY = "saved_lookups"


def _ensure_state() -> dict:
    if LOOKUPS_KEY not in st.session_state:
        st.session_state[LOOKUPS_KEY] = {}
    return st.session_state[LOOKUPS_KEY]


def _lookup_signature(spec: dict) -> str:
    return (
        f"{spec['env']} · {spec['owner']}.{spec['table']}"
        f"  ({spec['key_col']} → {spec['value_col']})"
    )


# ----------------------------------------------------------- browse ref table

def _browse(env: str, owner: str) -> None:
    saved = _ensure_state()

    with st.container(border=True):
        st.markdown(f"**Pick a reference table in `{owner}`**")
        with st.spinner(f"Loading reference tables from {owner}…"):
            all_tables = mq.list_tables(env, owner)["TABLE_NAME"].tolist()
        tables = [t for t in all_tables if t.upper().startswith(("CD", "REF"))]
        if not tables:
            st.info("No reference tables (CD* / REF*) found in this schema.")
            return
        table = st.selectbox(
            f"Reference table  ({len(tables)} found)",
            tables, index=None,
            placeholder="Select table (CD* / REF*)…",
            help="Only tables whose name starts with CD or REF are listed.",
            key="lkp_browse_table",
        )
        if not table:
            return

        with st.spinner("Loading columns…"):
            cols_df = mq.table_columns(env, owner, table)
        column_names = cols_df["COLUMN_NAME"].tolist()
        if not column_names:
            st.warning("No columns found.")
            return

        c3, c4 = st.columns(2)
        key_col = c3.selectbox(
            "Code column (key)", column_names, index=0,
            help="The column that holds the code (e.g. STATUS_ID).",
            key="lkp_browse_key",
        )
        # Default value column = the next column after key, if any.
        default_val_idx = 1 if len(column_names) > 1 else 0
        val_col = c4.selectbox(
            "Meaning column (value)", column_names, index=default_val_idx,
            help="The column that holds the human-readable label.",
            key="lkp_browse_val",
        )

    try:
        with st.spinner("Loading lookup pairs…"):
            df, secs = dq.load_lookup_pairs(env, owner, table, key_col, val_col)
    except Exception as exc:
        st.error(f"Failed to load reference table: {exc}")
        return

    if df.empty:
        st.info("Reference table is empty.")
        return

    st.success(f"Loaded {len(df):,} pair(s) in {secs:.2f}s.")

    # Save-as-lookup row
    with st.container(border=True):
        c1, c2 = st.columns([4, 1])
        default_name = f"{owner}.{table}.{key_col}"
        name = c1.text_input(
            "Save as lookup name", value=default_name, key="lkp_browse_name",
            help="Reuse this lookup from the Decode tab and Data Preview.",
        )
        c2.markdown("<div style='height:1.85rem'></div>", unsafe_allow_html=True)
        if c2.button("Save lookup", use_container_width=True,
                     key="lkp_browse_save"):
            if not name.strip():
                st.warning("Give the lookup a name.")
            else:
                saved[name.strip()] = {
                    "env": env, "owner": owner, "table": table,
                    "key_col": key_col, "value_col": val_col,
                }
                st.toast(f"Saved lookup: {name.strip()}")

    interactive_grid(
        df, key="lkp_browse_grid",
        download_basename=f"{owner}_{table}_{key_col}_to_{val_col}",
        height=420, show_search=True,
    )


# ------------------------------------------------------------- decode codes

def _decode() -> None:
    saved = _ensure_state()
    if not saved:
        st.info(
            "No saved lookups yet. Open the **Browse reference table** tab, "
            "load a reference table, and click **Save lookup**."
        )
        return

    with st.container(border=True):
        st.markdown("**Paste codes to decode**")
        c1, c2 = st.columns([3, 2])
        lookup_name = c1.selectbox(
            "Use saved lookup", list(saved.keys()),
            format_func=lambda n: f"{n}   —   {_lookup_signature(saved[n])}",
            key="lkp_decode_lookup",
        )
        delimiter_label = c2.selectbox(
            "Delimiter", ["Auto (comma / newline / space)", "Comma", "Newline", "Space"],
            key="lkp_decode_delim",
        )
        codes_raw = st.text_area(
            "Codes",
            placeholder="1, 2, 5\n7\nACTIVE",
            height=140, key="lkp_decode_input",
        )

    if not codes_raw or not lookup_name:
        st.caption("Enter at least one code.")
        return

    if delimiter_label.startswith("Auto"):
        import re
        codes = [c.strip() for c in re.split(r"[,\s]+", codes_raw) if c.strip()]
    elif delimiter_label == "Comma":
        codes = [c.strip() for c in codes_raw.split(",") if c.strip()]
    elif delimiter_label == "Newline":
        codes = [c.strip() for c in codes_raw.splitlines() if c.strip()]
    else:  # Space
        codes = [c.strip() for c in codes_raw.split() if c.strip()]

    spec = saved[lookup_name]
    try:
        with st.spinner("Loading lookup…"):
            mapping = dq.lookup_map(
                spec["env"], spec["owner"], spec["table"],
                spec["key_col"], spec["value_col"],
            )
    except Exception as exc:
        st.error(f"Failed to load lookup: {exc}")
        return

    rows = []
    unmatched: list[str] = []
    for c in codes:
        meaning = mapping.get(c)
        if meaning is None:
            unmatched.append(c)
            rows.append({"CODE": c, "MEANING": None, "FOUND": False})
        else:
            rows.append({"CODE": c, "MEANING": meaning, "FOUND": True})

    res = pd.DataFrame(rows)
    k1, k2, k3 = st.columns(3)
    k1.metric("Codes entered", len(res))
    k2.metric("Resolved", int(res["FOUND"].sum()))
    k3.metric("Unmatched", len(unmatched))

    interactive_grid(
        res[["CODE", "MEANING", "FOUND"]],
        key="lkp_decode_result",
        download_basename=f"decode_{lookup_name}",
        height=320, show_search=False,
    )

    if unmatched:
        with st.expander(f"{len(unmatched)} unmatched code(s)"):
            st.code("\n".join(unmatched))


# ------------------------------------------------------------- saved lookups

def _saved_panel() -> None:
    saved = _ensure_state()
    if not saved:
        st.info("No saved lookups yet.")
        return

    for name in list(saved.keys()):
        spec = saved[name]
        with st.container(border=True):
            c1, c2 = st.columns([5, 1])
            c1.markdown(f"**{name}**")
            c1.caption(_lookup_signature(spec))
            c2.markdown("<div style='height:0.3rem'></div>", unsafe_allow_html=True)
            if c2.button("Delete", key=f"lkp_del_{name}",
                         use_container_width=True, type="secondary"):
                del saved[name]
                st.rerun()


# --------------------------------------------------------------------- page

def render(env: str, owner: str | None) -> None:
    from components.cards import require_schema

    st.title("Code Lookups")
    st.caption(
        f"{env} · Decode codes (1 → Active, 0 → Inactive, …) without "
        "leaving the page. Save reference tables once, reuse anywhere."
    )

    if not require_schema(owner):
        return

    tabs = st.tabs(["Browse reference table", "Decode codes", "Saved lookups"])
    with tabs[0]:
        _browse(env, owner)
    with tabs[1]:
        _decode()
    with tabs[2]:
        _saved_panel()
