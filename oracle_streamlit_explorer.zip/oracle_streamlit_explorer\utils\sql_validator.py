"""Defensive SQL validation.

Two enforcement layers:
  1. assert_identifier  -> for any identifier we splice into SQL dynamically.
  2. is_safe_select     -> allow-list validator for ad-hoc user SQL.
  3. assert_safe_where  -> minimal lint for user-supplied WHERE clauses.
"""
from __future__ import annotations

import re

import sqlparse
from sqlparse.tokens import DDL, DML, Keyword

MAX_PREVIEW_ROWS = 10_000

# Oracle identifiers: letters, digits, _, $, #. Max 128 chars (12.2+).
# We refuse quoted identifiers to keep the surface small.
_IDENT_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_$#]{0,127}$")

# Statements that must never appear in a SELECT-only context.
_FORBIDDEN_KEYWORDS = {
    "INSERT", "UPDATE", "DELETE", "MERGE", "UPSERT",
    "DROP", "ALTER", "TRUNCATE", "CREATE", "RENAME",
    "GRANT", "REVOKE", "COMMIT", "ROLLBACK", "SAVEPOINT",
    "EXECUTE", "CALL", "BEGIN", "DECLARE", "LOCK",
    "PURGE", "FLASHBACK", "ANALYZE", "AUDIT", "NOAUDIT",
    "COMMENT",
}

_FORBIDDEN_IN_WHERE = _FORBIDDEN_KEYWORDS | {"SELECT", "UNION", "JOIN"}


class UnsafeSQLError(ValueError):
    """Raised when user input fails validation."""


def assert_identifier(value: str, *, kind: str = "identifier") -> None:
    if not isinstance(value, str) or not _IDENT_RE.match(value):
        raise UnsafeSQLError(f"Invalid {kind} name: {value!r}")


def assert_safe_where(clause: str) -> None:
    """Quick lint for user-supplied WHERE fragments. Bind values yourself."""
    if ";" in clause or "--" in clause or "/*" in clause or "*/" in clause:
        raise UnsafeSQLError("WHERE clause contains forbidden tokens (; -- /* */).")
    upper = clause.upper()
    tokens = re.findall(r"[A-Z_]+", upper)
    bad = set(tokens) & _FORBIDDEN_IN_WHERE
    if bad:
        raise UnsafeSQLError(
            f"WHERE clause contains forbidden keyword(s): {', '.join(sorted(bad))}"
        )


def is_safe_select(sql: str, *, raise_on_error: bool = False) -> bool:
    """Return True iff `sql` is a single read-only SELECT/WITH statement."""
    def _fail(msg: str) -> bool:
        if raise_on_error:
            raise UnsafeSQLError(msg)
        return False

    if not sql or not sql.strip():
        return _fail("Query is empty.")

    cleaned = sql.strip().rstrip(";").strip()
    if ";" in cleaned:
        return _fail("Only a single statement is allowed (no semicolons inside).")

    parsed = sqlparse.parse(cleaned)
    if len(parsed) != 1:
        return _fail("Only one SQL statement is allowed.")
    stmt = parsed[0]

    first = stmt.token_first(skip_cm=True, skip_ws=True)
    if first is None:
        return _fail("Could not parse statement.")
    head = first.normalized.upper()
    if head not in ("SELECT", "WITH"):
        return _fail("Only SELECT (or WITH ... SELECT) statements are allowed.")

    for tok in stmt.flatten():
        if tok.ttype in (DDL, DML):
            if tok.normalized.upper() not in ("SELECT",):
                return _fail(f"Forbidden statement type: {tok.normalized}")
        if tok.ttype is Keyword:
            kw = tok.normalized.upper()
            if kw in _FORBIDDEN_KEYWORDS:
                return _fail(f"Forbidden keyword: {kw}")
    return True
