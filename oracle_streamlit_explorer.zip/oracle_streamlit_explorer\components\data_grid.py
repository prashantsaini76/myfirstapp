"""Reusable interactive dataframe with global search + downloads."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from services.export_service import df_to_csv_bytes, df_to_xlsx_bytes


def interactive_grid(
    df: pd.DataFrame,
    *,
    key: str,
    download_basename: str = "data",
    height: int = 420,
    show_search: bool = True,
    show_download: bool = True,
) -> pd.DataFrame:
    if df is None or df.empty:
        st.info("No rows to display.")
        return pd.DataFrame()

    filtered = df
    if show_search:
        q = st.text_input(
            "Search",
            key=f"{key}_search",
            placeholder="Filter across all columns…",
            label_visibility="collapsed",
        )
        if q:
            ql = q.lower()
            mask = filtered.apply(
                lambda col: col.astype(str).str.lower().str.contains(ql, na=False)
            ).any(axis=1)
            filtered = filtered[mask]

    st.dataframe(filtered, use_container_width=True, height=height, hide_index=True)
    st.caption(f"Showing {len(filtered):,} of {len(df):,} rows.")

    if show_download:
        c1, c2 = st.columns(2)
        c1.download_button(
            "Download CSV",
            data=df_to_csv_bytes(filtered),
            file_name=f"{download_basename}.csv",
            mime="text/csv",
            use_container_width=True,
            key=f"{key}_csv",
        )
        c2.download_button(
            "Download Excel",
            data=df_to_xlsx_bytes(filtered, sheet_name=download_basename[:31]),
            file_name=f"{download_basename}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
            key=f"{key}_xlsx",
        )

    return filtered
