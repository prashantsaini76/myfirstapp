"""KPI metric cards + empty-state helper."""
from __future__ import annotations

import streamlit as st

from utils.formatting import humanize_int


def kpi_row(metrics: dict[str, int]) -> None:
    items = [
        ("Schemas",     metrics.get("schemas", 0)),
        ("Tables",      metrics.get("tables", 0)),
        ("Views",       metrics.get("views", 0)),
        ("Constraints", metrics.get("constraints", 0)),
        ("Indexes",     metrics.get("indexes", 0)),
    ]
    cols = st.columns(len(items))
    for col, (label, value) in zip(cols, items):
        with col:
            st.metric(label, humanize_int(value))


def require_schema(owner: str | None) -> bool:
    """Render an empty state if no schema selected. Returns True if OK to proceed."""
    if owner:
        return True
    st.info(
        "Select a schema from the sidebar to begin.",
        icon=None,
    )
    return False
