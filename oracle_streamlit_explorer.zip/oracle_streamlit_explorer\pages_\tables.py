"""Table Explorer + Table Detail with structured filter builder."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from components.cards import require_schema
from components.data_grid import interactive_grid
from db import data_queries as dq
from db import metadata_queries as mq
from services.table_service import find_tables, load_table_bundle, preview
from utils.filter_builder import OPERATORS, NEEDS_NO_VALUE, NEEDS_TWO, build_where
from utils.formatting import constraint_label, nullable_label
from utils.sql_validator import MAX_PREVIEW_ROWS, UnsafeSQLError

LARGE_TABLE_THRESHOLD = 1_000_000


def render(env: str, owner: str | None) -> None:
    if not require_schema(owner):
        return

    st.title("Table Explorer")
    st.caption(f"{env} · {owner}")

    with st.spinner(f"Loading tables from {owner}…"):
        tables = find_tables(env, owner, None)
    if tables.empty:
        st.info("This schema has no tables.")
        return

    table_names = tables["TABLE_NAME"].tolist()
    chosen = st.selectbox(
        f"Select a table  ({len(table_names):,} available)",
        table_names,
        index=None,
        placeholder="Type to search and select a table…",
        help="Start typing to filter the dropdown.",
        key="tbl_select",
    )

    if chosen:
        _render_detail(env, owner, chosen)
    else:
        st.caption(f"All tables in {owner}")
        interactive_grid(
            tables[
                ["TABLE_NAME", "NUM_ROWS", "LAST_ANALYZED",
                 "TABLESPACE_NAME", "STATUS", "COMMENTS"]
            ],
            key="tables_list",
            download_basename=f"{owner}_tables",
            height=480,
            show_search=False,
        )


# --------------------------------------------------------------- table detail

def _render_detail(env: str, owner: str, table: str) -> None:
    st.subheader(f"{owner}.{table}")

    with st.spinner(f"Loading metadata for {owner}.{table}…"):
        bundle = load_table_bundle(env, owner, table)
    if not bundle.overview.empty:
        row = bundle.overview.iloc[0]
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Rows (stat)",
                  f"{int(row['NUM_ROWS']):,}" if pd.notna(row["NUM_ROWS"]) else "—")
        c2.metric("Last analyzed",
                  row["LAST_ANALYZED"].strftime("%Y-%m-%d")
                  if pd.notna(row["LAST_ANALYZED"]) else "—")
        c3.metric("Tablespace", row["TABLESPACE_NAME"] or "—")
        c4.metric("Status", row["STATUS"] or "—")
        if row.get("COMMENTS"):
            st.caption(row["COMMENTS"])

    tabs = st.tabs([
        "Overview", "Columns", "Constraints", "Indexes",
        "Data Preview", "Find Value", "Relationships",
    ])

    with tabs[0]:
        st.dataframe(bundle.overview.T.rename(columns={0: "value"}),
                     use_container_width=True)

    with tabs[1]:
        cols = bundle.columns.copy()
        if not cols.empty:
            cols["NULLABLE"] = cols["NULLABLE"].map(nullable_label)
        interactive_grid(cols, key="col_grid",
                         download_basename=f"{owner}_{table}_columns",
                         height=400, show_search=True)

    with tabs[2]:
        cons = bundle.constraints.copy()
        if not cons.empty:
            cons["TYPE"] = cons["CONSTRAINT_TYPE"].map(constraint_label)
        interactive_grid(cons, key="cons_grid",
                         download_basename=f"{owner}_{table}_constraints",
                         height=380)

    with tabs[3]:
        interactive_grid(bundle.indexes, key="idx_grid",
                         download_basename=f"{owner}_{table}_indexes",
                         height=380)

    with tabs[4]:
        _render_data_preview(env, owner, table, bundle.overview, bundle.columns)

    with tabs[5]:
        _render_find_value(env, owner, table, bundle.columns)

    with tabs[6]:
        st.markdown("**References (this table → other tables)**")
        interactive_grid(bundle.fk_out, key="fk_out",
                         download_basename=f"{owner}_{table}_fk_out", height=240)
        st.markdown("**Referenced by (other tables → this table)**")
        interactive_grid(bundle.fk_in, key="fk_in",
                         download_basename=f"{owner}_{table}_fk_in", height=240)


# ----------------------------------------------------------- data preview UI

def _filter_state_key(owner: str, table: str) -> str:
    return f"filters::{owner}.{table}"


def _render_filter_builder(columns_df: pd.DataFrame, state_key: str) -> list[dict]:
    """Render N filter rows; persist in session_state[state_key]."""
    if state_key not in st.session_state:
        st.session_state[state_key] = []

    filters: list[dict] = st.session_state[state_key]
    column_names = columns_df["COLUMN_NAME"].tolist() if not columns_df.empty else []

    if not filters:
        st.caption("No filters. Click **Add filter** to build a WHERE clause.")

    # render each row
    to_delete: list[int] = []
    for i, f in enumerate(filters):
        row = st.columns([3, 2, 4, 4, 1])
        col_default = column_names.index(f["column"]) if f.get("column") in column_names else 0
        if column_names:
            f["column"] = row[0].selectbox(
                "Column", column_names, index=col_default,
                key=f"{state_key}_col_{i}", label_visibility="collapsed",
            )
        else:
            row[0].text("—")
            f["column"] = ""

        op_default = OPERATORS.index(f["op"]) if f.get("op") in OPERATORS else 0
        f["op"] = row[1].selectbox(
            "Operator", OPERATORS, index=op_default,
            key=f"{state_key}_op_{i}", label_visibility="collapsed",
        )

        if f["op"] in NEEDS_NO_VALUE:
            row[2].markdown("&nbsp;", unsafe_allow_html=True)
            row[3].markdown("&nbsp;", unsafe_allow_html=True)
            f["value"] = None
            f["value2"] = None
        elif f["op"] in NEEDS_TWO:
            f["value"] = row[2].text_input(
                "From", value=f.get("value") or "",
                key=f"{state_key}_v_{i}", label_visibility="collapsed",
                placeholder="from",
            )
            f["value2"] = row[3].text_input(
                "To", value=f.get("value2") or "",
                key=f"{state_key}_v2_{i}", label_visibility="collapsed",
                placeholder="to",
            )
        else:
            ph = "value1, value2, …" if f["op"] in {"IN", "NOT IN"} else "value"
            f["value"] = row[2].text_input(
                "Value", value=f.get("value") or "",
                key=f"{state_key}_v_{i}", label_visibility="collapsed",
                placeholder=ph,
            )
            row[3].markdown("&nbsp;", unsafe_allow_html=True)
            f["value2"] = None

        if row[4].button("✕", key=f"{state_key}_del_{i}", help="Remove filter"):
            to_delete.append(i)

    if to_delete:
        for i in reversed(to_delete):
            filters.pop(i)
        st.session_state[state_key] = filters
        st.rerun()

    c1, c2, _ = st.columns([1, 1, 4])
    if c1.button("Add filter", use_container_width=True, disabled=not column_names):
        filters.append({"column": column_names[0], "op": "=", "value": "", "value2": ""})
        st.rerun()
    if c2.button("Clear all", use_container_width=True, disabled=not filters):
        st.session_state[state_key] = []
        st.rerun()

    return filters


def _render_data_preview(env: str, owner: str, table: str,
                         overview: pd.DataFrame, columns: pd.DataFrame) -> None:
    num_rows_stat = (
        int(overview.iloc[0]["NUM_ROWS"])
        if not overview.empty and pd.notna(overview.iloc[0]["NUM_ROWS"])
        else None
    )
    if num_rows_stat and num_rows_stat > LARGE_TABLE_THRESHOLD:
        st.warning(
            f"Large table (~{num_rows_stat:,} rows by stats). "
            "Use filters and keep the row limit small."
        )

    column_types = (
        dict(zip(columns["COLUMN_NAME"], columns["DATA_TYPE"]))
        if not columns.empty else {}
    )

    with st.container(border=True):
        st.markdown("**Filters**")
        state_key = _filter_state_key(owner, table)
        filters = _render_filter_builder(columns, state_key)

    with st.container(border=True):
        st.markdown("**Result options**")
        c1, c2, c3, c4 = st.columns([1, 2, 2, 1])
        limit = c1.number_input(
            "Row limit", min_value=1, max_value=MAX_PREVIEW_ROWS,
            value=100, step=50,
        )
        col_options = ["(none)"] + (columns["COLUMN_NAME"].tolist() if not columns.empty else [])
        order_by_label = c2.selectbox("Order by", col_options)
        order_by = None if order_by_label == "(none)" else order_by_label
        order_dir = c3.selectbox("Direction", ["ASC", "DESC"])
        c4.markdown(
            "<div style='height:1.85rem'></div>", unsafe_allow_html=True,
        )
        run = c4.button("Run", type="primary", use_container_width=True)

    result_key = f"preview_result::{owner}.{table}"

    if run:
        try:
            where_sql, binds = build_where(filters, column_types)
        except UnsafeSQLError as exc:
            st.error(str(exc))
            st.session_state.pop(result_key, None)
        else:
            try:
                with st.spinner(f"Running query on {owner}.{table}…"):
                    df, sql, secs = preview(
                        env, owner, table,
                        limit=int(limit),
                        where_sql=where_sql,
                        binds=binds,
                        order_by=order_by,
                        order_dir=order_dir,
                    )
                st.session_state[result_key] = {
                    "df": df, "sql": sql, "secs": secs, "binds": binds,
                }
            except UnsafeSQLError as exc:
                st.error(f"Rejected: {exc}")
                st.session_state.pop(result_key, None)
            except Exception as exc:
                st.error(f"Query failed: {exc}")
                st.session_state.pop(result_key, None)

    # Render last result (if any) — survives reruns from filter edits.
    cached = st.session_state.get(result_key)
    if cached:
        st.success(f"Loaded {len(cached['df']):,} row(s) in {cached['secs']:.2f}s.")
        with st.expander("Generated SQL"):
            st.code(cached["sql"], language="sql")
            if cached["binds"]:
                st.write("Bind values:", cached["binds"])

        display_df = _apply_lookup_decodes(cached["df"], owner, table)
        interactive_grid(
            display_df, key="preview_grid",
            download_basename=f"{owner}_{table}_sample",
            height=480,
        )

    _render_decode_attachments(env, owner, table, cached["df"] if cached else None)

    st.divider()
    if st.button("Get exact row count (COUNT(*))"):
        with st.spinner("Counting rows… this may take a while on large tables."):
            try:
                st.metric("Row count", f"{dq.row_count(env, owner, table):,}")
            except Exception as exc:
                st.error(str(exc))


# --------------------------------------------------------- decode attachments

def _decode_state_key(owner: str, table: str) -> str:
    return f"decodes::{owner}.{table}"


def _render_decode_attachments(env: str, owner: str, table: str,
                               result_df: pd.DataFrame | None) -> None:
    """Let user attach saved or ad-hoc lookups for this table's columns."""
    state_key = _decode_state_key(owner, table)
    if state_key not in st.session_state:
        st.session_state[state_key] = {}  # column_name -> lookup_name

    if "saved_lookups" not in st.session_state:
        st.session_state["saved_lookups"] = {}
    saved: dict = st.session_state["saved_lookups"]
    attached: dict = st.session_state[state_key]

    if result_df is None or result_df.empty:
        cols_available = []
    else:
        cols_available = [c for c in result_df.columns if not c.endswith("__DECODED")]

    with st.expander(
        f"Decode column values  ·  {len(attached)} attached",
        expanded=False,
    ):
        if not cols_available:
            st.caption("Run a preview first to pick columns from the result.")
            return

        mode = st.radio(
            "Lookup source",
            ["Quick decode (pick reference table)", "Use a saved lookup"],
            index=0 if not saved else 1,
            horizontal=True,
            key=f"{state_key}_mode",
            label_visibility="collapsed",
        )

        if mode.startswith("Quick"):
            _render_quick_decode(env, owner, table, cols_available, saved, attached)
        else:
            _render_saved_decode(saved, attached, cols_available, state_key)

        # ----- existing attachments -----
        if attached:
            st.markdown("**Active decodes**")
            for col, lookup_name in list(attached.items()):
                r1, r2, r3 = st.columns([3, 4, 1])
                r1.text_input("Column", value=col, disabled=True,
                              label_visibility="collapsed",
                              key=f"{state_key}_show_col_{col}")
                spec = saved.get(lookup_name)
                sig = (
                    f"{spec['owner']}.{spec['table']}"
                    f" ({spec['key_col']} → {spec['value_col']})"
                    if spec else lookup_name
                )
                r2.text_input("Lookup", value=sig, disabled=True,
                              label_visibility="collapsed",
                              key=f"{state_key}_show_lk_{col}")
                if r3.button("Remove", key=f"{state_key}_rm_{col}",
                             use_container_width=True):
                    del attached[col]
                    st.rerun()


def _render_quick_decode(
    env: str, current_owner: str, current_table: str,
    cols_available: list[str], saved: dict, attached: dict,
) -> None:
    """Pick a reference table inline and attach as a lookup in one click."""
    state_key = _decode_state_key(current_owner, current_table) + "_quick"
    ref_owner = current_owner  # use sidebar's schema; no redundant picker

    with st.spinner(f"Loading reference tables from {ref_owner}…"):
        all_tables = mq.list_tables(env, ref_owner)["TABLE_NAME"].tolist()
    ref_tables = [t for t in all_tables if t.upper().startswith(("CD", "REF"))]

    c1, c2 = st.columns(2)
    col_choice = c1.selectbox(
        "Column to decode", cols_available, index=None,
        placeholder="Pick a column…", key=f"{state_key}_col",
    )
    if not ref_tables:
        c2.selectbox("Reference table", [],
                     placeholder=f"No CD*/REF* tables in {ref_owner}",
                     disabled=True, key=f"{state_key}_table")
        return
    ref_table = c2.selectbox(
        f"Reference table in {ref_owner}  ({len(ref_tables)} found)",
        ref_tables, index=None,
        placeholder="e.g. CDORGTP",
        help="Only tables whose name starts with CD or REF are listed.",
        key=f"{state_key}_table",
    )
    if not ref_table:
        return

    with st.spinner("Loading reference columns…"):
        ref_cols = mq.table_columns(env, ref_owner, ref_table)["COLUMN_NAME"].tolist()

    c3, c4, c5 = st.columns([2, 2, 1])
    key_col = c3.selectbox(
        "Code column", ref_cols, index=0 if ref_cols else None,
        help="Code column in the reference table (e.g. CD, ORG_TP_CD).",
        key=f"{state_key}_key",
    )
    default_val_idx = 1 if len(ref_cols) > 1 else 0
    val_col = c4.selectbox(
        "Meaning column", ref_cols, index=default_val_idx,
        help="Human-readable label column (e.g. DESCRIPTION, NAME).",
        key=f"{state_key}_val",
    )
    c5.markdown("<div style='height:1.85rem'></div>", unsafe_allow_html=True)
    can_apply = bool(col_choice and ref_table and key_col and val_col)
    if c5.button("Decode", type="primary", use_container_width=True,
                 disabled=not can_apply, key=f"{state_key}_apply"):
        name = f"{ref_owner}.{ref_table}.{key_col}"
        saved[name] = {
            "env": env, "owner": ref_owner, "table": ref_table,
            "key_col": key_col, "value_col": val_col,
        }
        attached[col_choice] = name
        st.toast(f"Decoded {col_choice} using {name}")
        st.rerun()


def _render_saved_decode(saved: dict, attached: dict,
                         cols_available: list[str], state_key: str) -> None:
    if not saved:
        st.caption(
            "No saved lookups yet. Use **Quick decode** instead, or open "
            "**Code Lookups → Browse reference table** to create one."
        )
        return

    c1, c2, c3 = st.columns([3, 3, 1])
    col_choice = c1.selectbox(
        "Column", cols_available, index=None,
        placeholder="Pick a column…", key=f"{state_key}_pick_col",
    )
    lookup_choice = c2.selectbox(
        "Lookup", list(saved.keys()), index=None,
        placeholder="Pick a saved lookup…", key=f"{state_key}_pick_lookup",
    )
    c3.markdown("<div style='height:1.85rem'></div>", unsafe_allow_html=True)
    if c3.button("Attach", use_container_width=True,
                 key=f"{state_key}_attach",
                 disabled=not (col_choice and lookup_choice)):
        attached[col_choice] = lookup_choice
        st.rerun()


def _apply_lookup_decodes(df: pd.DataFrame, owner: str,
                          table: str) -> pd.DataFrame:
    """Return a copy of df with `<col>__DECODED` columns added for attached lookups."""
    state_key = _decode_state_key(owner, table)
    attached: dict = st.session_state.get(state_key, {})
    saved = st.session_state.get("saved_lookups") or {}
    if not attached or df.empty:
        return df

    out = df.copy()
    for col, lookup_name in attached.items():
        if col not in out.columns or lookup_name not in saved:
            continue
        spec = saved[lookup_name]
        try:
            mapping = dq.lookup_map(
                spec["env"], spec["owner"], spec["table"],
                spec["key_col"], spec["value_col"],
            )
        except Exception:
            continue
        decoded = out[col].apply(
            lambda v: mapping.get(str(v)) if v is not None and not pd.isna(v) else None
        )
        new_col = f"{col}__DECODED"
        # insert decoded column immediately after the source column
        idx = out.columns.get_loc(col)
        out.insert(idx + 1, new_col, decoded)
    return out


# ------------------------------------------------------------- find value

MODE_LABELS = {
    "contains":  "Contains",
    "exact":     "Exact match",
    "starts":    "Starts with",
    "ends":      "Ends with",
}


def _render_find_value(env: str, owner: str, table: str, columns: pd.DataFrame) -> None:
    if columns.empty:
        st.info("No columns to search.")
        return

    column_names = columns["COLUMN_NAME"].tolist()
    state_key = f"find_value::{owner}.{table}"

    with st.container(border=True):
        st.markdown("**Search for a value across this table's columns**")
        c1, c2, c3 = st.columns([4, 2, 1])
        value = c1.text_input(
            "Value", key=f"{state_key}_val",
            placeholder="Value to search (e.g. 12345, ACTIVE, john@example.com)",
        )
        mode_key = c2.selectbox(
            "Match", list(MODE_LABELS.keys()),
            format_func=lambda k: MODE_LABELS[k],
            key=f"{state_key}_mode",
        )
        c3.markdown("<div style='height:1.85rem'></div>", unsafe_allow_html=True)
        run = c3.button("Search", type="primary", use_container_width=True,
                        key=f"{state_key}_run")

        c4, c5, c6 = st.columns([2, 2, 2])
        case_insensitive = c4.toggle(
            "Case-insensitive", value=True, key=f"{state_key}_ci",
            help="Matches are compared after UPPER() on both sides.",
        )
        scan_limit = c5.number_input(
            "Row scan limit", min_value=1_000, max_value=10_000_000,
            value=100_000, step=10_000,
            help="Only the first N rows of the table are scanned. "
                 "Increase for completeness on large tables.",
            key=f"{state_key}_scan",
        )
        selected_cols = c6.multiselect(
            "Columns to search", column_names, default=column_names,
            key=f"{state_key}_cols",
            help="By default every column is searched. Reduce for speed.",
        )

    result_key = f"{state_key}_result"

    if run:
        if not value:
            st.warning("Enter a value to search.")
        elif not selected_cols:
            st.warning("Select at least one column to search.")
        else:
            try:
                with st.spinner(
                    f"Scanning {len(selected_cols)} column(s) "
                    f"in the first {scan_limit:,} rows…"
                ):
                    df, sql, secs = dq.find_value_columns(
                        env, owner, table,
                        value=value,
                        columns=selected_cols,
                        mode=mode_key,
                        case_insensitive=case_insensitive,
                        scan_limit=int(scan_limit),
                    )
                st.session_state[result_key] = {
                    "df": df, "sql": sql, "secs": secs,
                    "value": value, "mode": mode_key, "ci": case_insensitive,
                    "scan_limit": int(scan_limit),
                }
            except Exception as exc:
                st.error(f"Search failed: {exc}")
                st.session_state.pop(result_key, None)

    cached = st.session_state.get(result_key)
    if not cached:
        st.info("Enter a value and click **Search**.")
        return

    df = cached["df"]
    if df.empty:
        st.warning(
            f"No column contained '{cached['value']}' "
            f"({MODE_LABELS[cached['mode']]}"
            f"{', case-insensitive' if cached['ci'] else ''}) "
            f"in the first {cached['scan_limit']:,} row(s)."
        )
        with st.expander("Generated SQL"):
            st.code(cached["sql"], language="sql")
        return

    st.success(
        f"Found matches in {len(df)} column(s) "
        f"(scanned {cached['scan_limit']:,} rows in {cached['secs']:.2f}s)."
    )
    interactive_grid(
        df.rename(columns={"COLUMN_NAME": "COLUMN", "HITS": "MATCH_COUNT"}),
        key=f"{state_key}_hits",
        download_basename=f"{owner}_{table}_find_{cached['value']}",
        height=320, show_search=False, show_download=True,
    )
    with st.expander("Generated SQL"):
        st.code(cached["sql"], language="sql")

    # ----- sample rows for a chosen matching column -----
    st.divider()
    matching_cols = df["COLUMN_NAME"].tolist()
    chosen = st.selectbox(
        "Show sample rows where the value was found",
        matching_cols, index=None, placeholder="Pick a column…",
        key=f"{state_key}_sample_col",
    )
    if chosen:
        try:
            with st.spinner(f"Loading sample rows for {chosen}…"):
                sdf, ssql, ssecs = dq.find_value_samples(
                    env, owner, table, chosen,
                    value=cached["value"],
                    mode=cached["mode"],
                    case_insensitive=cached["ci"],
                    sample_rows=20,
                    scan_limit=cached["scan_limit"],
                )
        except Exception as exc:
            st.error(f"Sample query failed: {exc}")
            return
        st.caption(f"Top {len(sdf)} matching rows for `{chosen}` (in {ssecs:.2f}s)")
        with st.expander("Generated SQL"):
            st.code(ssql, language="sql")
        interactive_grid(
            sdf, key=f"{state_key}_samples",
            download_basename=f"{owner}_{table}_{chosen}_samples",
            height=400, show_search=False,
        )
