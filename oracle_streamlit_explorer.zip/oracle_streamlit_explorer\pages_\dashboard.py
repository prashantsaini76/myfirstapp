"""Landing dashboard."""
from __future__ import annotations

import streamlit as st

from components.cards import kpi_row, require_schema
from db import metadata_queries as mq


def render(env: str, owner: str | None) -> None:
    st.title("Database Overview")
    st.caption(f"Environment: {env}")

    hide_system = bool(st.session_state.get("hide_system_schemas", False))
    with st.spinner("Loading database statistics…"):
        metrics = mq.kpi_counts(env, hide_system=hide_system)
    kpi_row(metrics)

    st.divider()

    if not require_schema(owner):
        return

    c1, c2 = st.columns([2, 1])
    with c1:
        st.subheader(f"Tables in {owner}")
        with st.spinner("Loading tables…"):
            tables = mq.list_tables(env, owner)
        if tables.empty:
            st.info("This schema has no tables.")
        else:
            st.dataframe(
                tables[["TABLE_NAME", "NUM_ROWS", "LAST_ANALYZED", "TABLESPACE_NAME"]]
                .head(25),
                use_container_width=True,
                hide_index=True,
            )
            st.caption(f"Top 25 of {len(tables):,}. Open Table Explorer for full list.")
    with c2:
        st.subheader("Views")
        with st.spinner("Loading views…"):
            views = mq.list_views(env, owner)
        if views.empty:
            st.info("No views.")
        else:
            st.dataframe(views[["VIEW_NAME"]].head(25),
                         use_container_width=True, hide_index=True)
            st.caption(f"Top 25 of {len(views):,}.")
