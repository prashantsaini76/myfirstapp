@echo off
REM API Log Viewer - Windows launcher
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed or not on PATH.
  echo Install Python 3.9+ from https://www.python.org/downloads/ and re-run.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"

echo Installing dependencies...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt

echo.
echo Launching API Log Viewer at http://localhost:8501
python -m streamlit run app.py

endlocal
