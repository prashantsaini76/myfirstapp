#!/usr/bin/env bash
# API Log Viewer - macOS/Linux launcher
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed or not on PATH."
  echo "Install Python 3.9+ from https://www.python.org/downloads/ and re-run."
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "Creating virtual environment..."
  python3 -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate

echo "Installing dependencies..."
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt

echo
echo "Launching API Log Viewer at http://localhost:8501"
python -m streamlit run app.py
