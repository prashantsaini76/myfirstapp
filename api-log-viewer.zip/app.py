"""Enterprise Log Analyzer - Streamlit dashboard for request/response logs."""
from __future__ import annotations

import io
import json
import re
import uuid
from datetime import datetime
from typing import Any

import pandas as pd
import requests
import streamlit as st

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

LINE_RE = re.compile(
    r"^\[(?P<ts>[^\]]+)\]\s+"
    r"\[(?P<api>[^\]]+)\]\s+"
    r"\[(?P<log_type>[^\]]+)\]\s+"
    r"\[(?P<component>[^\]]+)\]\s+"
    r"\[(?P<mdc>[^\]]*)\]\s*-\s*(?P<desc>.*)$"
)

REQ_MARK = "::RECEIVED-REQUEST::"
REQ_END = "::END-OF-REQUEST::"
RESP_MARK = "::RETURNED-RESPONSE::"
RESP_END = "::END-OF-RESPONSE::"

REMOVED_HEADERS = {"vinzauthorization", "singularityheader"}
HARDCODED_AUTH = ("Authorization", "Bearer <your token>")

TS_FORMATS = ["%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"]


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def read_uploaded_file(uploaded) -> str:
    if uploaded is None:
        return ""
    data = uploaded.read()
    if isinstance(data, bytes):
        for enc in ("utf-8", "latin-1"):
            try:
                return data.decode(enc)
            except UnicodeDecodeError:
                continue
        return data.decode("utf-8", errors="replace")
    return str(data)


def fetch_log_from_url(url: str, verify_ssl: bool = True, timeout: int = 30) -> str:
    resp = requests.get(url, verify=verify_ssl, timeout=timeout)
    resp.raise_for_status()
    return resp.text


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_ts(s: str) -> datetime | None:
    s = s.strip()
    for fmt in TS_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def pretty_json(value: Any) -> str:
    """Best-effort pretty JSON. Handles escaped JSON strings and dict-like text."""
    if value is None or value == "":
        return ""
    if isinstance(value, (dict, list)):
        try:
            return json.dumps(value, indent=2, ensure_ascii=False)
        except (TypeError, ValueError):
            return str(value)
    if not isinstance(value, str):
        return str(value)
    s = value.strip()
    if not s:
        return ""
    candidates = [s]
    if "\\\"" in s or "\\\\" in s:
        try:
            candidates.append(json.loads(f'"{s}"'))
        except (json.JSONDecodeError, ValueError):
            pass
        candidates.append(s.replace('\\"', '"').replace("\\\\", "\\"))
    for c in candidates:
        try:
            obj = json.loads(c)
            return json.dumps(obj, indent=2, ensure_ascii=False)
        except (json.JSONDecodeError, TypeError):
            continue
    return value


# ---------------------------------------------------------------------------
# Header parsing
# ---------------------------------------------------------------------------

def parse_headers(headers_str: str) -> dict[str, str]:
    """Parse `key1=[val1], key2=[val2], ...` allowing brackets/commas inside values."""
    out: dict[str, str] = {}
    if not headers_str:
        return out
    s = headers_str.strip()
    i, n = 0, len(s)
    while i < n:
        eq = s.find("=[", i)
        if eq == -1:
            break
        key = s[i:eq].strip().lstrip(",").strip()
        j = eq + 2
        depth = 1
        buf = []
        while j < n and depth > 0:
            ch = s[j]
            if ch == "[":
                depth += 1
                buf.append(ch)
            elif ch == "]":
                depth -= 1
                if depth == 0:
                    break
                buf.append(ch)
            else:
                buf.append(ch)
            j += 1
        val = "".join(buf)
        if key:
            out[key] = val
        i = j + 1
        while i < n and s[i] in ", ":
            i += 1
    return out


def clean_headers(headers: dict[str, str]) -> dict[str, str]:
    cleaned = {k: v for k, v in headers.items() if k.lower() not in REMOVED_HEADERS}
    cleaned[HARDCODED_AUTH[0]] = HARDCODED_AUTH[1]
    return cleaned


# ---------------------------------------------------------------------------
# Request / Response extraction
# ---------------------------------------------------------------------------

def extract_request_fields(block_text: str) -> dict[str, Any]:
    """Pull uri, method, headers dict, raw payload from a RECEIVED-REQUEST segment."""
    result = {"uri": "", "method": "", "headers": {}, "request_payload": ""}
    start = block_text.find(REQ_MARK)
    end = block_text.find(REQ_END)
    if start == -1:
        return result
    segment = block_text[start + len(REQ_MARK): end if end != -1 else len(block_text)]

    m = re.search(r"uri=(.*?);method=", segment, re.DOTALL)
    if m:
        result["uri"] = m.group(1).strip()
    m = re.search(r"method=([^;]+);", segment)
    if m:
        result["method"] = m.group(1).strip()

    h_start = segment.find("headers={")
    if h_start != -1:
        i = h_start + len("headers={")
        depth = 1
        j = i
        while j < len(segment) and depth > 0:
            ch = segment[j]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        headers_raw = segment[i:j]
        result["headers"] = parse_headers(headers_raw)

    p = re.search(r"payload=(.*)$", segment, re.DOTALL)
    if p:
        result["request_payload"] = p.group(1).strip()
    return result


def extract_response_fields(block_text: str) -> dict[str, Any]:
    result = {"response_payload": "", "http_status": "", "response_headers": {}}
    start = block_text.find(RESP_MARK)
    end = block_text.find(RESP_END)
    if start == -1:
        return result
    segment = block_text[start + len(RESP_MARK): end if end != -1 else len(block_text)]

    m = re.search(r"HTTP STATUS=([^;]+);", segment)
    if m:
        result["http_status"] = m.group(1).strip()

    h_start = segment.find("headers={")
    if h_start != -1:
        i = h_start + len("headers={")
        depth = 1
        j = i
        while j < len(segment) and depth > 0:
            ch = segment[j]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        result["response_headers"] = parse_headers(segment[i:j])

    p = re.search(r"payload=(.*)$", segment, re.DOTALL)
    if p:
        result["response_payload"] = p.group(1).strip()
    return result


# ---------------------------------------------------------------------------
# Top-level parsing
# ---------------------------------------------------------------------------

def parse_log_line(line: str) -> dict[str, Any] | None:
    m = LINE_RE.match(line)
    if not m:
        return None
    return {
        "timestamp": m.group("ts").strip(),
        "api": m.group("api").strip(),
        "log_type": m.group("log_type").strip(),
        "component": m.group("component").strip(),
        "description": m.group("desc").strip(),
    }


def _flush_block(lines: list[str]) -> str:
    return "\n".join(lines).strip()


def parse_transactions(text: str) -> tuple[list[dict], list[dict]]:
    """Return (log_lines, transactions). Groups lines from RECEIVED-REQUEST..END-OF-RESPONSE."""
    log_rows: list[dict] = []
    txns: list[dict] = []

    current_lines: list[str] = []
    current_active = False
    block_counter = 0
    pending_correlation: str | None = None

    raw_lines = text.splitlines()
    # Stitch multi-line entries: a real log line starts with "[YYYY-..."
    stitched: list[str] = []
    for ln in raw_lines:
        if re.match(r"^\[\d{4}-\d{2}-\d{2}", ln):
            stitched.append(ln)
        else:
            if stitched:
                stitched[-1] = stitched[-1] + "\n" + ln
            # else: orphan preamble - skip
    for ln in stitched:
        parsed = parse_log_line(ln)
        if parsed:
            log_rows.append({**parsed, "correlation_id": None, "raw": ln})

        if REQ_MARK in ln:
            # start new block (close any unfinished one defensively)
            if current_active and current_lines:
                block_counter += 1
                txns.append(_finalize_txn(current_lines, block_counter, pending_correlation))
            current_lines = [ln]
            current_active = True
        elif current_active:
            current_lines.append(ln)
            if RESP_END in ln:
                block_counter += 1
                txns.append(_finalize_txn(current_lines, block_counter, None))
                current_lines = []
                current_active = False

    if current_active and current_lines:
        block_counter += 1
        txns.append(_finalize_txn(current_lines, block_counter, None))

    # Backfill correlation_id onto individual log lines using raw substring lookup
    for row in log_rows:
        raw = row.get("raw", "")
        for t in txns:
            if raw and raw in t["full_raw_block"]:
                row["correlation_id"] = t["correlation_id"]
                break

    for t in txns:
        t.pop("_line_ids", None)

    return log_rows, txns


def _finalize_txn(block_lines: list[str], block_num: int, _pending: str | None) -> dict:
    block_text = "\n".join(block_lines)
    req = extract_request_fields(block_text)
    resp = extract_response_fields(block_text)
    headers = req["headers"]

    correlation_id = headers.get("correlation-id") or headers.get("Correlation-Id") or ""
    if not correlation_id:
        correlation_id = f"txn-{block_num:06d}"

    channel = headers.get("channel-id") or headers.get("requestsystemname") or ""

    # timestamps for duration
    first_ts = None
    last_ts = None
    for bl in block_lines:
        m = LINE_RE.match(bl.split("\n", 1)[0])
        if not m:
            continue
        ts = parse_ts(m.group("ts"))
        if ts is None:
            continue
        if first_ts is None or REQ_MARK in bl:
            if first_ts is None:
                first_ts = ts
            if REQ_MARK in bl:
                first_ts = ts
        if RESP_MARK in bl or RESP_END in bl:
            last_ts = ts
        if last_ts is None:
            last_ts = ts

    duration_ms = None
    if first_ts and last_ts:
        duration_ms = int((last_ts - first_ts).total_seconds() * 1000)

    # api / component come from the first RECEIVED-REQUEST line
    first_parsed = None
    for bl in block_lines:
        first_parsed = parse_log_line(bl.split("\n", 1)[0])
        if first_parsed:
            break

    cleaned_headers = clean_headers(headers)
    headers_json = json.dumps(cleaned_headers, indent=2, ensure_ascii=False)

    req_payload_pretty = pretty_json(req["request_payload"]) or ""
    resp_payload_pretty = pretty_json(resp["response_payload"]) or ""

    # remember which log_row indices belong to this block
    line_ids: list[int] = []  # filled by caller would be tricky; use raw lookup later
    # Instead we rebuild membership using block raw text:
    return {
        "correlation_id": correlation_id,
        "timestamp": first_parsed["timestamp"] if first_parsed else "",
        "api": first_parsed["api"] if first_parsed else "",
        "component": first_parsed["component"] if first_parsed else "",
        "uri": req["uri"],
        "method": req["method"],
        "channel": channel,
        "http_status": resp["http_status"],
        "duration_ms": duration_ms if duration_ms is not None else "",
        "headers": headers_json,
        "request_payload": req_payload_pretty,
        "response_payload": resp_payload_pretty,
        "full_raw_block": block_text,
        "_line_ids": line_ids,  # placeholder; we'll backfill below
    }


# ---------------------------------------------------------------------------
# Dataframes
# ---------------------------------------------------------------------------

def build_transaction_dataframe(txns: list[dict]) -> pd.DataFrame:
    cols = [
        "correlation_id", "timestamp", "api", "uri", "method", "channel",
        "http_status", "duration_ms", "component", "headers",
        "request_payload", "response_payload", "full_raw_block",
    ]
    if not txns:
        return pd.DataFrame(columns=cols)
    df = pd.DataFrame(txns)
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    return df[cols]


def build_logline_dataframe(rows: list[dict]) -> pd.DataFrame:
    cols = ["timestamp", "api", "log_type", "component", "correlation_id", "description"]
    if not rows:
        return pd.DataFrame(columns=cols)
    df = pd.DataFrame(rows)
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    return df[cols]


# ---------------------------------------------------------------------------
# Filtering
# ---------------------------------------------------------------------------

SEARCH_FIELDS = [
    "correlation_id", "api", "component", "uri", "method", "channel",
    "headers", "request_payload", "response_payload", "description",
    "full_raw_block",
]


def _matches_keyword(row: pd.Series, keyword: str) -> bool:
    kw = keyword.lower()
    for f in SEARCH_FIELDS:
        v = row.get(f)
        if v is None:
            continue
        if kw in str(v).lower():
            return True
    return False


def apply_filters(df: pd.DataFrame, filters: dict) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()

    keyword = (filters.get("keyword") or "").strip()
    if keyword:
        out = out[out.apply(lambda r: _matches_keyword(r, keyword), axis=1)]

    for col in ("correlation_id", "api", "log_type", "component", "uri", "method", "channel", "http_status"):
        val = filters.get(col)
        if val:
            if isinstance(val, list):
                if val:
                    out = out[out[col].astype(str).isin([str(v) for v in val])]
            else:
                out = out[out[col].astype(str).str.contains(str(val), case=False, na=False)]

    ts_range = filters.get("ts_range")
    if ts_range and "timestamp" in out.columns:
        start, end = ts_range
        ts_series = pd.to_datetime(out["timestamp"], errors="coerce")
        if start:
            out = out[ts_series >= pd.Timestamp(start)]
            ts_series = pd.to_datetime(out["timestamp"], errors="coerce")
        if end:
            out = out[ts_series <= pd.Timestamp(end)]

    dur_range = filters.get("duration_range")
    if dur_range and "duration_ms" in out.columns:
        lo, hi = dur_range
        d = pd.to_numeric(out["duration_ms"], errors="coerce")
        if lo is not None:
            out = out[d >= lo]
            d = pd.to_numeric(out["duration_ms"], errors="coerce")
        if hi is not None:
            out = out[d <= hi]

    # Section-specific keyword searches
    for section in ("headers", "request_payload", "response_payload"):
        key = filters.get(f"{section}_search")
        if key and section in out.columns:
            out = out[out[section].astype(str).str.contains(key, case=False, na=False)]

    # Advanced filter builder
    adv = filters.get("advanced")
    if adv:
        rules = adv.get("rules", [])
        logic = adv.get("logic", "AND").upper()
        if rules:
            def _row_match(row: pd.Series) -> bool:
                results = []
                for r in rules:
                    field = r.get("field")
                    op = r.get("op", "contains")
                    val = r.get("value", "")
                    cell = str(row.get(field, ""))
                    if op == "equals":
                        results.append(cell.lower() == val.lower())
                    elif op == "not_equals":
                        results.append(cell.lower() != val.lower())
                    elif op == "contains":
                        results.append(val.lower() in cell.lower())
                    elif op == "not_contains":
                        results.append(val.lower() not in cell.lower())
                    elif op == "regex":
                        try:
                            results.append(bool(re.search(val, cell)))
                        except re.error:
                            results.append(False)
                return all(results) if logic == "AND" else any(results)

            out = out[out.apply(_row_match, axis=1)]

    return out


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def _safe_metric(label: str, value: Any) -> None:
    st.metric(label, "-" if value in ("", None) else value)


def render_kpis(txn_df: pd.DataFrame, line_df: pd.DataFrame) -> None:
    total_lines = len(line_df)
    total_txns = len(txn_df)
    unique_cid = txn_df["correlation_id"].nunique() if not txn_df.empty else 0
    total_apis = txn_df["api"].nunique() if not txn_df.empty else 0

    status_series = pd.to_numeric(txn_df["http_status"], errors="coerce") if not txn_df.empty else pd.Series([], dtype=float)
    error_count = int((status_series.fillna(0) >= 400).sum()) if not txn_df.empty else 0

    dur_series = pd.to_numeric(txn_df["duration_ms"], errors="coerce") if not txn_df.empty else pd.Series([], dtype=float)
    avg_dur = round(dur_series.dropna().mean(), 2) if not dur_series.dropna().empty else 0
    slowest = int(dur_series.dropna().max()) if not dur_series.dropna().empty else 0

    top_api = txn_df["api"].mode().iat[0] if not txn_df.empty and not txn_df["api"].mode().empty else ""
    top_uri = txn_df["uri"].mode().iat[0] if not txn_df.empty and not txn_df["uri"].mode().empty else ""
    top_status = txn_df["http_status"].mode().iat[0] if not txn_df.empty and not txn_df["http_status"].mode().empty else ""

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1: _safe_metric("Total log lines", total_lines)
    with c2: _safe_metric("Total transactions", total_txns)
    with c3: _safe_metric("Unique correlation IDs", unique_cid)
    with c4: _safe_metric("Total APIs", total_apis)
    with c5: _safe_metric("Errors (>=400)", error_count)

    c6, c7, c8, c9, c10 = st.columns(5)
    with c6: _safe_metric("Avg duration (ms)", avg_dur)
    with c7: _safe_metric("Slowest (ms)", slowest)
    with c8: _safe_metric("Top API", top_api)
    with c9: _safe_metric("Top URI", top_uri)
    with c10: _safe_metric("Top HTTP status", top_status)


def render_overview(txn_df: pd.DataFrame, line_df: pd.DataFrame) -> None:
    render_kpis(txn_df, line_df)
    if txn_df.empty:
        st.info("No transactions parsed yet.")
        return

    col_a, col_b = st.columns(2)
    with col_a:
        st.subheader("HTTP status distribution")
        s = txn_df["http_status"].replace("", pd.NA).dropna().value_counts()
        if not s.empty:
            st.bar_chart(s)
        else:
            st.caption("No HTTP status values found.")

        st.subheader("API-wise transaction count")
        a = txn_df["api"].replace("", pd.NA).dropna().value_counts()
        if not a.empty:
            st.bar_chart(a)

    with col_b:
        st.subheader("Slowest transactions")
        dur = pd.to_numeric(txn_df["duration_ms"], errors="coerce")
        slow = txn_df.assign(_d=dur).sort_values("_d", ascending=False).head(10)
        st.dataframe(
            slow[["correlation_id", "api", "uri", "method", "http_status", "duration_ms"]],
            use_container_width=True, hide_index=True,
        )

        st.subheader("Top URIs")
        u = txn_df["uri"].replace("", pd.NA).dropna().value_counts().head(10).rename_axis("uri").reset_index(name="count")
        st.dataframe(u, use_container_width=True, hide_index=True)

        st.subheader("Top components")
        c = txn_df["component"].replace("", pd.NA).dropna().value_counts().head(10).rename_axis("component").reset_index(name="count")
        st.dataframe(c, use_container_width=True, hide_index=True)


def render_transactions(txn_df: pd.DataFrame) -> None:
    if txn_df.empty:
        st.info("No transactions to display.")
        return
    summary_cols = ["correlation_id", "timestamp", "api", "uri", "method", "channel", "http_status", "duration_ms"]
    st.dataframe(txn_df[summary_cols], use_container_width=True, hide_index=True)

    st.markdown("### Inspect transaction")
    cid = st.selectbox("Select correlation_id", txn_df["correlation_id"].tolist(), key="txn_inspect")
    row = txn_df[txn_df["correlation_id"] == cid].iloc[0]

    with st.expander("Headers (cleaned JSON)", expanded=False):
        st.code(row["headers"], language="json")
    with st.expander("Request payload", expanded=False):
        st.code(row["request_payload"] or "(empty)", language="json")
    with st.expander("Response payload", expanded=False):
        st.code(row["response_payload"] or "(empty)", language="json")
    with st.expander("Raw block", expanded=False):
        st.code(row["full_raw_block"], language="text")


def render_log_lines(line_df: pd.DataFrame) -> None:
    if line_df.empty:
        st.info("No log lines parsed.")
        return
    q = st.text_input("Search log lines", key="line_search")
    df = line_df
    if q:
        mask = df.apply(lambda r: q.lower() in " ".join(str(v) for v in r.values).lower(), axis=1)
        df = df[mask]
    st.dataframe(df, use_container_width=True, hide_index=True)


def render_payload_viewer(txn_df: pd.DataFrame) -> None:
    if txn_df.empty:
        st.info("No transactions available.")
        return
    cid = st.selectbox("Select correlation_id", txn_df["correlation_id"].tolist(), key="payload_cid")
    row = txn_df[txn_df["correlation_id"] == cid].iloc[0]
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Request payload")
        st.code(row["request_payload"] or "(empty)", language="json")
    with col2:
        st.subheader("Response payload")
        st.code(row["response_payload"] or "(empty)", language="json")


def render_header_viewer(txn_df: pd.DataFrame) -> None:
    if txn_df.empty:
        st.info("No transactions available.")
        return
    cid = st.selectbox("Select correlation_id", txn_df["correlation_id"].tolist(), key="hdr_cid")
    row = txn_df[txn_df["correlation_id"] == cid].iloc[0]
    st.code(row["headers"], language="json")


def render_raw_logs(txn_df: pd.DataFrame) -> None:
    if txn_df.empty:
        st.info("No transactions available.")
        return
    cid = st.selectbox("Select correlation_id", txn_df["correlation_id"].tolist(), key="raw_cid")
    q = st.text_input("Search within raw block", key="raw_search")
    row = txn_df[txn_df["correlation_id"] == cid].iloc[0]
    text = row["full_raw_block"]
    if q:
        st.caption(f"Matches: {text.lower().count(q.lower())}")
    st.code(text, language="text")


def render_export_section(txn_df: pd.DataFrame, line_df: pd.DataFrame) -> None:
    st.subheader("Export")
    col1, col2, col3 = st.columns(3)

    with col1:
        st.download_button(
            "Download filtered transactions (CSV)",
            data=txn_df.to_csv(index=False).encode("utf-8"),
            file_name="transactions.csv",
            mime="text/csv",
            disabled=txn_df.empty,
        )
        st.download_button(
            "Download filtered log lines (CSV)",
            data=line_df.to_csv(index=False).encode("utf-8"),
            file_name="log_lines.csv",
            mime="text/csv",
            disabled=line_df.empty,
        )

    with col2:
        if not txn_df.empty:
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as writer:
                txn_df.drop(columns=["full_raw_block"], errors="ignore").to_excel(
                    writer, index=False, sheet_name="transactions"
                )
                line_df.to_excel(writer, index=False, sheet_name="log_lines")
            st.download_button(
                "Download transaction summary (Excel)",
                data=buf.getvalue(),
                file_name="transactions.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

    with col3:
        if not txn_df.empty:
            cid = st.selectbox("Raw block for", txn_df["correlation_id"].tolist(), key="export_cid")
            row = txn_df[txn_df["correlation_id"] == cid].iloc[0]
            st.download_button(
                "Download raw block (TXT)",
                data=row["full_raw_block"].encode("utf-8"),
                file_name=f"{cid}.txt",
                mime="text/plain",
            )


# ---------------------------------------------------------------------------
# Sidebar filters
# ---------------------------------------------------------------------------

def sidebar_filters(txn_df: pd.DataFrame) -> dict:
    st.sidebar.header("Filters")
    filters: dict = {}
    filters["keyword"] = st.sidebar.text_input("Global keyword search")

    with st.sidebar.expander("Column filters", expanded=False):
        if not txn_df.empty:
            filters["correlation_id"] = st.text_input("correlation_id contains")
            filters["api"] = st.multiselect("api", sorted(txn_df["api"].dropna().unique().tolist()))
            filters["component"] = st.text_input("component contains")
            filters["uri"] = st.text_input("uri contains")
            filters["method"] = st.multiselect("method", sorted(txn_df["method"].dropna().unique().tolist()))
            filters["channel"] = st.multiselect("channel", sorted(txn_df["channel"].dropna().unique().tolist()))
            filters["http_status"] = st.multiselect("http_status", sorted(txn_df["http_status"].dropna().astype(str).unique().tolist()))

            tsa, tsb = st.columns(2)
            with tsa:
                start_date = st.date_input("From date", value=None, key="from_date")
            with tsb:
                end_date = st.date_input("To date", value=None, key="to_date")
            filters["ts_range"] = (start_date, end_date)

            dur_series = pd.to_numeric(txn_df["duration_ms"], errors="coerce").dropna()
            if not dur_series.empty:
                lo, hi = int(dur_series.min()), int(dur_series.max())
                if lo == hi:
                    hi = lo + 1
                rng = st.slider("duration_ms", lo, hi, (lo, hi))
                filters["duration_range"] = rng

    with st.sidebar.expander("Section search", expanded=False):
        filters["headers_search"] = st.text_input("Search in headers")
        filters["request_payload_search"] = st.text_input("Search in request payload")
        filters["response_payload_search"] = st.text_input("Search in response payload")

    with st.sidebar.expander("Advanced filter builder", expanded=False):
        logic = st.radio("Combine with", ["AND", "OR"], horizontal=True, key="adv_logic")
        n = st.number_input("Number of rules", 0, 8, 0, step=1, key="adv_n")
        rules = []
        fields = ["correlation_id", "api", "component", "uri", "method", "channel",
                  "http_status", "headers", "request_payload", "response_payload", "description"]
        ops = ["contains", "not_contains", "equals", "not_equals", "regex"]
        for i in range(int(n)):
            c1, c2, c3 = st.columns([2, 2, 3])
            with c1:
                f = st.selectbox(f"Field {i+1}", fields, key=f"adv_f_{i}")
            with c2:
                o = st.selectbox(f"Op {i+1}", ops, key=f"adv_o_{i}")
            with c3:
                v = st.text_input(f"Value {i+1}", key=f"adv_v_{i}")
            if v != "":
                rules.append({"field": f, "op": o, "value": v})
        filters["advanced"] = {"logic": logic, "rules": rules}

    return filters


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _load_text() -> str:
    st.markdown("#### Input")
    mode = st.radio(
        "Source",
        ["Upload Log File", "Paste Log Content", "Fetch From URL"],
        horizontal=True,
    )
    text = ""
    if mode == "Upload Log File":
        up = st.file_uploader("Choose .log or .txt", type=["log", "txt"])
        if up is not None:
            text = read_uploaded_file(up)
    elif mode == "Paste Log Content":
        text = st.text_area("Paste log content", height=240)
    else:
        url = st.text_input("Log URL", placeholder="https://example.com/app.log")
        bypass = st.checkbox("Bypass SSL/certificate verification (verify=False)")
        if bypass:
            st.warning("SSL verification is disabled. Use only with trusted internal endpoints.")
        if url and st.button("Fetch"):
            try:
                text = fetch_log_from_url(url, verify_ssl=not bypass)
                st.success(f"Fetched {len(text):,} characters.")
                st.session_state["fetched_text"] = text
            except requests.RequestException as e:
                st.error(f"Fetch failed: {e}")
            except Exception as e:
                st.error(f"Unexpected error: {e}")
        text = st.session_state.get("fetched_text", text)

    col_p, col_c = st.columns([1, 1])
    with col_p:
        parse_clicked = st.button("Parse", type="primary", use_container_width=True)
    with col_c:
        if st.button("Clear / Reset", use_container_width=True):
            for k in ("parsed_text", "fetched_text", "txn_df", "line_df"):
                st.session_state.pop(k, None)
            st.rerun()

    if parse_clicked and text:
        st.session_state["parsed_text"] = text

    return st.session_state.get("parsed_text", "")


def main() -> None:
    st.set_page_config(page_title="API Log Viewer", layout="wide")
    st.markdown(
        """
        <style>
        [data-testid="stMetricValue"] { font-size: 1.25rem; white-space: normal; word-break: break-word; line-height: 1.2; }
        [data-testid="stMetricLabel"] { font-size: 0.8rem; }
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.title("API Log Viewer")
    st.caption(
        "Parses request/response transaction logs and helps investigate transactions "
        "by correlation_id."
    )

    text = _load_text()

    if not text:
        st.info("Provide logs via upload, paste, or URL fetch, then click Parse.")
        return

    try:
        log_rows, txns = parse_transactions(text)
    except Exception as e:
        st.error(f"Parsing failed: {e}")
        return

    txn_df = build_transaction_dataframe(txns)
    line_df = build_logline_dataframe(log_rows)

    filters = sidebar_filters(txn_df)
    f_txn = apply_filters(txn_df, filters)
    f_line = apply_filters(line_df, {
        "keyword": filters.get("keyword", ""),
        "api": filters.get("api"),
        "log_type": filters.get("log_type"),
        "component": filters.get("component"),
        "correlation_id": filters.get("correlation_id"),
        "ts_range": filters.get("ts_range"),
        "advanced": filters.get("advanced"),
    })

    tabs = st.tabs([
        "Overview", "Transactions", "Log Lines", "Raw Logs", "Export",
    ])
    with tabs[0]:
        render_overview(f_txn, f_line)
    with tabs[1]:
        render_transactions(f_txn)
    with tabs[2]:
        render_log_lines(f_line)
    with tabs[3]:
        render_raw_logs(f_txn)
    with tabs[4]:
        render_export_section(f_txn, f_line)


if __name__ == "__main__":
    main()
