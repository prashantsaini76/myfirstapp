# API Log Viewer

A Streamlit dashboard that parses request/response transaction logs and helps
investigate transactions by correlation_id.

Transaction blocks start with `::RECEIVED-REQUEST::` and end with `::END-OF-RESPONSE::`.

---

## How to run on another machine

### 1. Prerequisites
- Python 3.9 or newer installed and on PATH
  - Verify: `python --version`
  - Download: https://www.python.org/downloads/

### 2. Unzip
Extract `api-log-viewer.zip` to any folder, e.g. `C:\api-log-viewer` or `~/api-log-viewer`.

### 3. (Recommended) Create a virtual environment

Windows (PowerShell):
```powershell
cd C:\api-log-viewer
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Windows (cmd):
```cmd
cd C:\api-log-viewer
python -m venv .venv
.venv\Scripts\activate.bat
```

macOS / Linux:
```bash
cd ~/api-log-viewer
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies
```
pip install -r requirements.txt
```

### 5. Launch the app
```
streamlit run app.py
```

Your browser will open at `http://localhost:8501`. If it does not, open that URL manually.

To stop the server: press `Ctrl + C` in the terminal.

---

## Quick-start scripts

For convenience the zip includes:
- `run.bat`  - double-click on Windows. Creates venv (if missing), installs deps, launches the app.
- `run.sh`   - run via `bash run.sh` on macOS / Linux.

---

## Input options
1. Upload a `.log` or `.txt` file
2. Paste raw log content
3. Fetch from URL (optional SSL bypass via `verify=False`)

## Log format
```
[timestamp] [api] [log_type] [component] [{}] - description
```

## Header cleaning
- Removes `vinzauthorization` and `singularityheader`
- Adds `"Authorization": "Bearer <your token>"`

## Troubleshooting
- **`python` not recognized** - install Python and tick "Add to PATH" during setup.
- **`streamlit` not recognized** - activate the venv first, or run `python -m streamlit run app.py`.
- **PowerShell blocks venv activation** - run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
- **Port 8501 busy** - `streamlit run app.py --server.port 8600`.
